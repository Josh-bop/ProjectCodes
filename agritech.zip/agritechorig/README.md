# AgriTech — Setup Instructions

## First-time setup (after unzipping)

The `node_modules` folders have been removed to keep the zip small.
Run these commands once to restore all dependencies:

### 1. Backend
```bash
cd backend
npm install
```

### 2. Frontend
```bash
cd frontend
npm install
```

---

## Running the app

Open **two terminals**:

**Terminal 1 — Backend**
```bash
cd backend
npm run dev
```
Backend runs at: http://localhost:5000

**Terminal 2 — Frontend**
```bash
cd frontend
npm run dev
```
Frontend runs at: http://localhost:5173

---

## Admin account
```
Email:    admin@agritech.com
Password: Admin@1234
```

If the admin account is missing (e.g. after a database wipe), run:
```bash
cd backend
node create-admin.js
```

---

## Environment variables
The `.env` file is already included in `backend/.env`.
Do **not** share this file publicly as it contains database credentials.
