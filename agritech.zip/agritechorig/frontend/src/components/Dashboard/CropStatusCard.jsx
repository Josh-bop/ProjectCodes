import React, { useState, useEffect } from 'react';
import { Card, Badge, ProgressBar, Button, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaSeedling, FaExclamationTriangle, FaCheckCircle } from 'react-icons/fa';
import { getUserCrops } from '../../services/cropService';
import { toast } from 'react-toastify';

const CropStatusCard = () => {
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCrops();
  }, []);

  const fetchCrops = async () => {
    try {
      const data = await getUserCrops();
      setCrops(data.slice(0, 4));
    } catch (error) {
      toast.error('Failed to load crops');
    } finally {
      setLoading(false);
    }
  };

  const getGrowthProgress = (stage) => {
    const stages = ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting'];
    const index = stages.indexOf(stage);
    return ((index + 1) / stages.length) * 100;
  };

  const getHealthBadge = (health) => {
    const variants = { excellent: 'success', good: 'info', fair: 'warning', poor: 'danger', critical: 'dark' };
    return variants[health] || 'secondary';
  };

  if (loading) return <Card><Card.Body>Loading crops...</Card.Body></Card>;

  return (
    <Card className="mb-4 shadow-sm">
      <Card.Header className="bg-white d-flex justify-content-between align-items-center">
        <h5 className="mb-0"><FaSeedling className="me-2 text-success" />Active Crops</h5>
        <Button as={Link} to="/crops" variant="outline-success" size="sm">View All</Button>
      </Card.Header>
      <Card.Body>
        {crops.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-muted">No crops added yet.</p>
            <Button as={Link} to="/crops" variant="success">Add Your First Crop</Button>
          </div>
        ) : (
          crops.map((crop) => (
            <div key={crop._id} className="mb-3 pb-3 border-bottom">
              <div className="d-flex justify-content-between align-items-center mb-2">
                <div>
                  <strong className="fs-5">{crop.name}</strong>
                  <Badge bg={getHealthBadge(crop.health)} className="ms-2">{crop.health}</Badge>
                  <Badge bg="secondary" className="ms-2">{crop.growthStage}</Badge>
                </div>
                {crop.alerts?.length > 0 && <FaExclamationTriangle className="text-warning" />}
              </div>
              <ProgressBar 
                now={getGrowthProgress(crop.growthStage)} 
                variant="success" 
                className="mb-2"
                style={{ height: '8px' }}
              />
              <div className="d-flex justify-content-between small text-muted">
                <span>🌱 Planted: {new Date(crop.plantingDate).toLocaleDateString()}</span>
                {crop.expectedHarvestDate && (
                  <span>📅 Harvest: {new Date(crop.expectedHarvestDate).toLocaleDateString()}</span>
                )}
              </div>
            </div>
          ))
        )}
      </Card.Body>
    </Card>
  );
};

export default CropStatusCard;