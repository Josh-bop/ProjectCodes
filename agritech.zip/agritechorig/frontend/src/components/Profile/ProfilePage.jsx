import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Container, Row, Col, Card, Form, Button, Alert, 
  Spinner, Image, Badge, ProgressBar, Tabs, Tab, Modal
} from 'react-bootstrap';
import { 
  FaUser, FaEnvelope, FaPhone, FaMapMarkerAlt, FaCamera, 
  FaTractor, FaSeedling, FaChartLine, FaHistory, FaEdit, 
  FaSave, FaTimes, FaLeaf, FaCalendarAlt, FaCheckCircle,
  FaSpinner, FaUpload
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import Navbar from '../Layout/Navbar';
import Footer from '../Layout/Footer';
import { useAuth } from '../../context/AuthContext';

const ProfilePage = () => {
  const navigate = useNavigate();
  const { user: authUser, logout, refreshUser } = useAuth(); // Added refreshUser
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const [stats, setStats] = useState({
    totalFarms: 0,
    totalCrops: 0,
    activeCrops: 0,
    totalPosts: 0,
    memberSince: '',
    lastActive: ''
  });
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    location: {
      city: '',
      state: '',
      pincode: ''
    },
    farmExperience: '',
    bio: '',
    profilePicture: ''
  });

  // Get token from localStorage
  const getAuthHeaders = () => ({
    headers: { 
      'Authorization': `Bearer ${localStorage.getItem('token')}`,
      'Content-Type': 'application/json'
    }
  });

  useEffect(() => {
    fetchUserProfile();
    fetchUserStats();
  }, []);

  const fetchUserProfile = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:5000/api/auth/profile', getAuthHeaders());
      setUser(response.data);
      setFormData({
        name: response.data.name || '',
        email: response.data.email || '',
        phone: response.data.phone || '',
        location: response.data.location || { city: '', state: '', pincode: '' },
        farmExperience: response.data.farmExperience || '',
        bio: response.data.bio || '',
        profilePicture: response.data.profilePicture || ''
      });
    } catch (error) {
      console.error('Error fetching profile:', error);
      if (error.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        logout();
        navigate('/login');
      } else {
        toast.error('Failed to load profile');
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchUserStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = { headers: { Authorization: `Bearer ${token}` } };
      
      const [farmsRes, cropsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/farms', config),
        axios.get('http://localhost:5000/api/crops', config)
      ]);
      
      const crops = cropsRes.data || [];
      const activeCrops = crops.filter(c => 
        c.growthStage !== 'harvesting' && c.growthStage !== 'fallow'
      ).length;
      
      setStats({
        totalFarms: farmsRes.data?.length || 0,
        totalCrops: crops.length,
        activeCrops: activeCrops,
        totalPosts: 0,
        memberSince: user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : 'January 2024',
        lastActive: user?.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Today'
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: { ...prev[parent], [child]: value }
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      const response = await axios.put('http://localhost:5000/api/auth/profile', 
        {
          name: formData.name,
          phone: formData.phone,
          location: formData.location,
          farmExperience: formData.farmExperience,
          bio: formData.bio
        }, 
        getAuthHeaders()
      );
      setUser(response.data);
      // Refresh user data in context to update navbar
      await refreshUser();
      toast.success('Profile updated successfully!');
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error(error.response?.data?.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    // Check file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }
    
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size should be less than 5MB');
      return;
    }
    
    setUploadingImage(true);
    
    const uploadFormData = new FormData();
    uploadFormData.append('image', file);
    
    try {
      // First upload the image
      const uploadResponse = await axios.post('http://localhost:5000/api/upload/single', uploadFormData, {
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'multipart/form-data'
        }
      });
      
      console.log('Upload response:', uploadResponse.data);
      
      if (uploadResponse.data.success) {
        const imageUrl = uploadResponse.data.url;
        
        // Then update user profile with new image URL
        const updateResponse = await axios.put('http://localhost:5000/api/auth/profile', 
          { profilePicture: imageUrl }, 
          getAuthHeaders()
        );
        
        console.log('Profile update response:', updateResponse.data);
        
        setUser(updateResponse.data);
        setFormData(prev => ({ ...prev, profilePicture: imageUrl }));
        
        // Refresh user data in context to update navbar immediately
        await refreshUser();
        
        toast.success('Profile picture updated!');
        setShowImageModal(false);
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error(error.response?.data?.message || 'Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const getProfileImageUrl = () => {
    if (formData.profilePicture && formData.profilePicture.startsWith('/uploads/')) {
      return `http://localhost:5000${formData.profilePicture}`;
    }
    if (user?.profilePicture && user.profilePicture.startsWith('/uploads/')) {
      return `http://localhost:5000${user.profilePicture}`;
    }
    return 'https://via.placeholder.com/150?text=No+Image';
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #e8f5e9', borderTopColor: '#2e7d32', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#4caf50', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading profile...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <Container fluid className="mt-4 px-4">
        <Row>
          {/* Sidebar / Profile Card */}
          <Col lg={4}>
            <Card className="shadow-sm mb-4">
              <Card.Body className="text-center">
                <div className="position-relative d-inline-block">
                  <Image 
                    src={getProfileImageUrl()}
                    roundedCircle 
                    style={{ 
                      width: '150px', 
                      height: '150px', 
                      objectFit: 'cover', 
                      border: '4px solid #4caf50',
                      cursor: 'pointer'
                    }}
                    onClick={() => setShowImageModal(true)}
                  />
                  <div 
                    onClick={() => setShowImageModal(true)}
                    style={{
                      position: 'absolute',
                      bottom: '10px',
                      right: '10px',
                      background: '#2e7d32',
                      borderRadius: '50%',
                      padding: '8px',
                      cursor: 'pointer',
                      color: 'white',
                      transition: 'all 0.3s'
                    }}
                  >
                    <FaCamera />
                  </div>
                </div>
                <h3 className="mt-3 mb-1">{user?.name}</h3>
                <Badge bg={user?.role === 'farmer' ? 'success' : user?.role === 'expert' ? 'info' : 'danger'} className="mb-3">
                  {user?.role === 'farmer' ? '🌾 Farmer' : user?.role === 'expert' ? '👨‍🌾 Expert' : '👑 Admin'}
                </Badge>
                <p className="text-muted">
                  <FaEnvelope className="me-2" /> {user?.email}
                </p>
                {user?.phone && (
                  <p className="text-muted">
                    <FaPhone className="me-2" /> {user?.phone}
                  </p>
                )}
                <hr />
                <div className="text-start">
                  <h6>📊 Farm Statistics</h6>
                  <div className="d-flex justify-content-between mt-2">
                    <span>Total Farms:</span>
                    <strong>{stats.totalFarms}</strong>
                  </div>
                  <div className="d-flex justify-content-between mt-1">
                    <span>Total Crops:</span>
                    <strong>{stats.totalCrops}</strong>
                  </div>
                  <div className="d-flex justify-content-between mt-1">
                    <span>Active Crops:</span>
                    <strong>{stats.activeCrops}</strong>
                  </div>
                </div>
                <hr />
                <div className="text-start">
                  <small className="text-muted">
                    <FaCalendarAlt className="me-1" /> Member since {stats.memberSince}
                  </small>
                  <br />
                  <small className="text-muted">
                    <FaCheckCircle className="me-1 text-success" /> Last active {stats.lastActive}
                  </small>
                </div>
              </Card.Body>
            </Card>
          </Col>

          {/* Main Content */}
          <Col lg={8}>
            <Card className="shadow-sm">
              <Card.Header className="bg-white d-flex justify-content-between align-items-center">
                <h5 className="mb-0">Profile Information</h5>
                {!editing ? (
                  <Button variant="outline-success" size="sm" onClick={() => setEditing(true)}>
                    <FaEdit className="me-1" /> Edit Profile
                  </Button>
                ) : (
                  <div>
                    <Button variant="outline-secondary" size="sm" onClick={() => setEditing(false)} className="me-2">
                      <FaTimes className="me-1" /> Cancel
                    </Button>
                    <Button variant="success" size="sm" onClick={handleSubmit} disabled={saving}>
                      <FaSave className="me-1" /> {saving ? 'Saving...' : 'Save Changes'}
                    </Button>
                  </div>
                )}
              </Card.Header>
              <Card.Body>
                <Tabs defaultActiveKey="personal" className="mb-3">
                  <Tab eventKey="personal" title="Personal Info">
                    <Form>
                      <Form.Group className="mb-3">
                        <Form.Label>Full Name</Form.Label>
                        <Form.Control
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          disabled={!editing}
                          placeholder="Your full name"
                        />
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Email Address</Form.Label>
                        <Form.Control
                          type="email"
                          name="email"
                          value={formData.email}
                          disabled={true}
                          readOnly
                        />
                        <Form.Text className="text-muted">Email cannot be changed</Form.Text>
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Phone Number</Form.Label>
                        <Form.Control
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          disabled={!editing}
                          placeholder="09XXXXXXXXX"
                        />
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Bio / About</Form.Label>
                        <Form.Control
                          as="textarea"
                          rows={3}
                          name="bio"
                          value={formData.bio}
                          onChange={handleChange}
                          disabled={!editing}
                          placeholder="Tell us about your farming journey..."
                        />
                      </Form.Group>
                    </Form>
                  </Tab>

                  <Tab eventKey="location" title="Location">
                    <Form>
                      <Row>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>City</Form.Label>
                            <Form.Control
                              type="text"
                              name="location.city"
                              value={formData.location.city}
                              onChange={handleChange}
                              disabled={!editing}
                              placeholder="Your city"
                            />
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>State</Form.Label>
                            <Form.Control
                              type="text"
                              name="location.state"
                              value={formData.location.state}
                              onChange={handleChange}
                              disabled={!editing}
                              placeholder="Your state"
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      <Form.Group className="mb-3">
                        <Form.Label>Pincode</Form.Label>
                        <Form.Control
                          type="text"
                          name="location.pincode"
                          value={formData.location.pincode}
                          onChange={handleChange}
                          disabled={!editing}
                          placeholder="Postal code"
                        />
                      </Form.Group>
                    </Form>
                  </Tab>

                  <Tab eventKey="farming" title="Farming Experience">
                    <Form>
                      <Form.Group className="mb-3">
                        <Form.Label>Farming Experience Level</Form.Label>
                        <Form.Select
                          name="farmExperience"
                          value={formData.farmExperience}
                          onChange={handleChange}
                          disabled={!editing}
                        >
                          <option value="">Select experience level</option>
                          <option value="beginner">🌱 Beginner (Less than 1 year)</option>
                          <option value="intermediate">🌿 Intermediate (1-5 years)</option>
                          <option value="expert">🌾 Expert (5+ years)</option>
                        </Form.Select>
                      </Form.Group>

                      {formData.farmExperience && (
                        <Alert variant="info" className="mt-3">
                          <h6>💡 Farming Tips for You:</h6>
                          {formData.farmExperience === 'beginner' && (
                            <p className="mb-0">Start with easy-to-grow crops like tomatoes, eggplant, and okra. Join our community forum for daily tips!</p>
                          )}
                          {formData.farmExperience === 'intermediate' && (
                            <p className="mb-0">Great! Consider diversifying your crops and exploring organic farming methods.</p>
                          )}
                          {formData.farmExperience === 'expert' && (
                            <p className="mb-0">Share your wisdom in our community forum and help fellow farmers!</p>
                          )}
                        </Alert>
                      )}
                    </Form>
                  </Tab>
                </Tabs>
              </Card.Body>
            </Card>

            {/* Recent Activity Card */}
            <Card className="shadow-sm mt-4">
              <Card.Header className="bg-white">
                <h5 className="mb-0"><FaHistory className="me-2" /> Recent Activity</h5>
              </Card.Header>
              <Card.Body>
                <div className="text-center py-4">
                  <FaLeaf size={40} className="text-muted mb-2" />
                  <p className="text-muted mb-0">Your recent activities will appear here</p>
                  <small className="text-muted">Start adding farms and crops to see your activity!</small>
                </div>
              </Card.Body>
            </Card>

            {/* Farming Stats Card */}
            <Card className="shadow-sm mt-4">
              <Card.Header className="bg-white">
                <h5 className="mb-0"><FaChartLine className="me-2" /> Farming Overview</h5>
              </Card.Header>
              <Card.Body>
                <Row>
                  <Col md={4}>
                    <div className="text-center">
                      <FaTractor size={30} className="text-success mb-2" />
                      <h5>{stats.totalFarms}</h5>
                      <small className="text-muted">Total Farms</small>
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="text-center">
                      <FaSeedling size={30} className="text-success mb-2" />
                      <h5>{stats.totalCrops}</h5>
                      <small className="text-muted">Total Crops</small>
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="text-center">
                      <FaChartLine size={30} className="text-success mb-2" />
                      <h5>{stats.activeCrops}</h5>
                      <small className="text-muted">Active Crops</small>
                    </div>
                  </Col>
                </Row>
                <hr />
                <div className="mt-3">
                  <div className="d-flex justify-content-between">
                    <small>Profile Completion</small>
                    <small>
                      {Math.min(100,
                        (formData.name ? 30 : 0) + 
                        (formData.phone ? 20 : 0) + 
                        (formData.location.city ? 20 : 0) + 
                        (formData.farmExperience ? 15 : 0) + 
                        (formData.bio ? 15 : 0)
                      )}%
                    </small>
                  </div>
                  <ProgressBar 
                    now={Math.min(100,
                      (formData.name ? 30 : 0) + 
                      (formData.phone ? 20 : 0) + 
                      (formData.location.city ? 20 : 0) + 
                      (formData.farmExperience ? 15 : 0) + 
                      (formData.bio ? 15 : 0)
                    )} 
                    variant="success" 
                    className="mt-1"
                  />
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Image Upload Modal */}
        <Modal show={showImageModal} onHide={() => setShowImageModal(false)}>
          <Modal.Header closeButton className="gradient-bg text-white">
            <Modal.Title>Update Profile Picture</Modal.Title>
          </Modal.Header>
          <Modal.Body className="text-center">
            <Image 
              src={getProfileImageUrl()}
              roundedCircle 
              style={{ 
                width: '200px', 
                height: '200px', 
                objectFit: 'cover', 
                border: '3px solid #4caf50',
                marginBottom: '20px'
              }}
            />
            
            <div className="mb-3">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                style={{ display: 'none' }}
                id="profile-image-upload-modal"
              />
              <label htmlFor="profile-image-upload-modal">
                <Button 
                  variant="success" 
                  as="span"
                  disabled={uploadingImage}
                  className="me-2"
                >
                  {uploadingImage ? <FaSpinner className="spinner" /> : <FaUpload className="me-1" />}
                  {uploadingImage ? ' Uploading...' : ' Choose New Image'}
                </Button>
              </label>
              <Button variant="secondary" onClick={() => setShowImageModal(false)}>
                Cancel
              </Button>
            </div>
            
            <small className="text-muted">
              Recommended: Square image, max 5MB. JPG, PNG, or GIF.
            </small>
          </Modal.Body>
        </Modal>
      </Container>
      <Footer />

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .spinner { animation: spin 1s linear infinite; }
      `}</style>
    </>
  );
};

export default ProfilePage;