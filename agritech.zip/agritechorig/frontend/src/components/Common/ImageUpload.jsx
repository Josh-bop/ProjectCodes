import React, { useState } from 'react';
import { Form, Button, Row, Col, Alert } from 'react-bootstrap';
import { FaUpload, FaTrash, FaImage } from 'react-icons/fa';

const ImageUpload = ({ onImagesChange, multiple = true, maxImages = 5, existingImages = [] }) => {
  const [images, setImages] = useState(existingImages);
  const [previews, setPreviews] = useState([]);
  const [error, setError] = useState('');

  const handleImageSelect = (e) => {
    const files = Array.from(e.target.files);
    
    if (images.length + files.length > maxImages) {
      setError(`Maximum ${maxImages} images allowed`);
      return;
    }
    
    files.forEach(file => {
      if (!file.type.startsWith('image/')) {
        setError('Only image files are allowed');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size should be less than 5MB');
        return;
      }
    });
    
    const newPreviews = files.map(file => URL.createObjectURL(file));
    setPreviews([...previews, ...newPreviews]);
    setImages([...images, ...files]);
    onImagesChange([...images, ...files]);
    setError('');
  };

  const removeImage = (index) => {
    const newImages = images.filter((_, i) => i !== index);
    const newPreviews = previews.filter((_, i) => i !== index);
    setImages(newImages);
    setPreviews(newPreviews);
    onImagesChange(newImages);
  };

  return (
    <div>
      <Form.Group className="mb-3">
        <Form.Label>
          <FaImage className="me-2" /> Upload Images
        </Form.Label>
        <Form.Control
          type="file"
          accept="image/*"
          multiple={multiple}
          onChange={handleImageSelect}
          className="mb-2"
        />
        <small className="text-muted">
          Max {maxImages} images, each up to 5MB. Supported: JPG, PNG, GIF
        </small>
      </Form.Group>
      
      {error && <Alert variant="danger">{error}</Alert>}
      
      {previews.length > 0 && (
        <Row className="g-2 mt-2">
          {previews.map((preview, idx) => (
            <Col xs={6} md={3} key={idx}>
              <div className="position-relative">
                <img 
                  src={preview} 
                  alt={`Preview ${idx + 1}`}
                  style={{ width: '100%', height: '120px', objectFit: 'cover', borderRadius: '8px' }}
                />
                <Button
                  variant="danger"
                  size="sm"
                  className="position-absolute top-0 end-0 m-1"
                  onClick={() => removeImage(idx)}
                  style={{ borderRadius: '50%', padding: '2px 8px' }}
                >
                  <FaTrash />
                </Button>
              </div>
            </Col>
          ))}
        </Row>
      )}
    </div>
  );
};

export default ImageUpload;