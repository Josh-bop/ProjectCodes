import React from 'react';
import { FaLeaf } from 'react-icons/fa';

const LoadingSpinner = ({ message = 'Loading...' }) => {
  return (
    <div
      className="d-flex flex-column justify-content-center align-items-center fade-in"
      style={{ minHeight: '60vh', gap: '1rem' }}
    >
      <div style={{ position: 'relative', width: 56, height: 56 }}>
        {/* Spinning ring */}
        <div style={{
          position: 'absolute',
          inset: 0,
          borderRadius: '50%',
          border: '3px solid #e8f5e9',
          borderTopColor: '#2e7d32',
          animation: 'spin 0.9s linear infinite',
        }} />
        {/* Center icon */}
        <div style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          <FaLeaf style={{ color: '#4caf50', fontSize: '20px' }} />
        </div>
      </div>
      <p className="text-muted mb-0" style={{ fontSize: '0.9rem', fontWeight: 500 }}>
        {message}
      </p>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default LoadingSpinner;
