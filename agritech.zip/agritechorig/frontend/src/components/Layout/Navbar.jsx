import React, { useState, useEffect } from 'react';
import { Navbar, Nav, Container, Dropdown, Image, Badge } from 'react-bootstrap';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  FaUser, FaTractor, FaSignOutAlt, FaChartLine,
  FaComments, FaStore, FaLeaf, FaCog, FaSeedling,
  FaShieldAlt
} from 'react-icons/fa';

const AppNavbar = () => {
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [expanded, setExpanded] = useState(false);
  const [profilePicture, setProfilePicture] = useState('');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      if (userData.profilePicture) {
        setProfilePicture(
          userData.profilePicture.startsWith('/uploads/')
            ? `http://localhost:5000${userData.profilePicture}`
            : userData.profilePicture
        );
      }
    }
  }, [user]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
    setExpanded(false);
  };

  const isActive = (path) => location.pathname === path;

  const authLinks = [
    { to: '/dashboard', label: 'Dashboard', icon: <FaTractor size={14} className="me-1" />, show: !isAdmin },
    { to: '/farms',     label: 'Farms',     icon: <FaLeaf    size={14} className="me-1" />, show: !isAdmin },
    { to: '/crops',     label: 'Crops',     icon: <FaSeedling size={14} className="me-1" />, show: !isAdmin },
    { to: '/forum',     label: 'Forum',     icon: <FaComments size={14} className="me-1" />, show: true },
    { to: '/marketplace', label: 'Market', icon: <FaStore   size={14} className="me-1" />, show: true },
    { to: '/analytics', label: 'Analytics', icon: <FaChartLine size={14} className="me-1" />, show: !isAdmin },
    { to: '/admin',     label: 'Admin',     icon: <FaShieldAlt size={14} className="me-1" />, show: isAdmin },
  ];

  const getProfileImageUrl = () => {
    if (profilePicture) return profilePicture;
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      if (userData.profilePicture) {
        return userData.profilePicture.startsWith('/uploads/')
          ? `http://localhost:5000${userData.profilePicture}`
          : userData.profilePicture;
      }
    }
    return 'https://via.placeholder.com/40?text=U';
  };

  const getUserName = () => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      return userData.name?.split(' ')[0] || 'User';
    }
    return user?.name?.split(' ')[0] || 'User';
  };

  const getUserRole = () => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      return JSON.parse(storedUser).role || 'farmer';
    }
    return user?.role || 'farmer';
  };

  const roleBadgeColor = { admin: '#f44336', expert: '#00bcd4', farmer: '#66bb6a' };

  return (
    <Navbar
      expand="lg"
      className="navbar-custom"
      expanded={expanded}
      onToggle={setExpanded}
      style={{
        transition: 'box-shadow 0.3s ease',
        boxShadow: scrolled ? '0 4px 20px rgba(27,94,32,0.3)' : '0 2px 16px rgba(27,94,32,0.2)',
      }}
    >
      <Container>
        {/* Brand */}
        <Navbar.Brand
          as={Link}
          to={isAuthenticated ? (isAdmin ? '/admin' : '/dashboard') : '/'}
          className="text-white fw-bold d-flex align-items-center gap-2"
          style={{ fontSize: '1.2rem', letterSpacing: '-0.3px' }}
        >
          <div style={{
            background: 'rgba(255,255,255,0.2)',
            borderRadius: '10px',
            padding: '6px 8px',
            display: 'flex',
            alignItems: 'center',
          }}>
            <FaLeaf style={{ color: '#a5d6a7', fontSize: '18px' }} />
          </div>
          Agri<span style={{ color: '#a5d6a7' }}>Tech</span>
        </Navbar.Brand>

        <Navbar.Toggle
          aria-controls="main-navbar"
          style={{ borderColor: 'rgba(255,255,255,0.3)' }}
        />

        <Navbar.Collapse id="main-navbar">
          {/* Nav Links */}
          <Nav className="me-auto ms-3 gap-1">
            {isAuthenticated && authLinks.map((link, idx) =>
              link.show && (
                <Nav.Link
                  key={idx}
                  as={Link}
                  to={link.to}
                  onClick={() => setExpanded(false)}
                  style={{
                    color: isActive(link.to) ? '#ffffff' : 'rgba(255,255,255,0.82)',
                    background: isActive(link.to) ? 'rgba(255,255,255,0.18)' : 'transparent',
                    borderRadius: '8px',
                    fontWeight: isActive(link.to) ? 600 : 400,
                    fontSize: '0.875rem',
                    padding: '0.45rem 0.75rem',
                    display: 'flex',
                    alignItems: 'center',
                    transition: 'all 0.2s ease',
                  }}
                >
                  {link.icon}{link.label}
                </Nav.Link>
              )
            )}
          </Nav>

          {/* Right side */}
          <Nav className="align-items-center gap-2">
            {isAuthenticated ? (
              <Dropdown align="end">
                <Dropdown.Toggle
                  variant="link"
                  id="user-dropdown"
                  style={{ textDecoration: 'none', padding: '4px 8px', border: 'none' }}
                  className="d-flex align-items-center gap-2"
                >
                  <div style={{ position: 'relative' }}>
                    <Image
                      src={getProfileImageUrl()}
                      roundedCircle
                      style={{
                        width: 36,
                        height: 36,
                        objectFit: 'cover',
                        border: '2px solid rgba(255,255,255,0.7)',
                      }}
                    />
                    <span style={{
                      position: 'absolute',
                      bottom: 0,
                      right: 0,
                      width: 10,
                      height: 10,
                      background: '#69f0ae',
                      borderRadius: '50%',
                      border: '2px solid #2e7d32',
                    }} />
                  </div>
                  <div className="d-none d-lg-block text-start">
                    <div style={{ color: 'white', fontWeight: 600, fontSize: '0.85rem', lineHeight: 1.2 }}>
                      {getUserName()}
                    </div>
                    <div style={{
                      fontSize: '0.7rem',
                      color: '#a5d6a7',
                      textTransform: 'capitalize',
                    }}>
                      {getUserRole()}
                    </div>
                  </div>
                </Dropdown.Toggle>

                <Dropdown.Menu style={{ minWidth: '200px' }}>
                  <div className="px-3 py-2 mb-1" style={{ borderBottom: '1px solid #f0f0f0' }}>
                    <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{getUserName()}</div>
                    <div style={{ fontSize: '0.75rem', color: '#888', textTransform: 'capitalize' }}>
                      <span style={{
                        display: 'inline-block',
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        background: roleBadgeColor[getUserRole()] || '#66bb6a',
                        marginRight: 5,
                      }} />
                      {getUserRole()}
                    </div>
                  </div>
                  <Dropdown.Item as={Link} to="/profile" onClick={() => setExpanded(false)}>
                    <FaUser className="me-2 text-success" size={13} /> My Profile
                  </Dropdown.Item>
                  {!isAdmin && (
                    <Dropdown.Item as={Link} to="/farms" onClick={() => setExpanded(false)}>
                      <FaTractor className="me-2 text-success" size={13} /> My Farms
                    </Dropdown.Item>
                  )}
                  <Dropdown.Item as={Link} to="/profile" onClick={() => setExpanded(false)}>
                    <FaCog className="me-2 text-secondary" size={13} /> Settings
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={handleLogout} style={{ color: '#f44336' }}>
                    <FaSignOutAlt className="me-2" size={13} /> Sign Out
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            ) : (
              <div className="d-flex gap-2">
                <Nav.Link
                  as={Link}
                  to="/login"
                  onClick={() => setExpanded(false)}
                  style={{
                    color: 'rgba(255,255,255,0.9)',
                    border: '1.5px solid rgba(255,255,255,0.4)',
                    borderRadius: '10px',
                    padding: '0.4rem 1rem',
                    fontSize: '0.875rem',
                    fontWeight: 500,
                    transition: 'all 0.2s ease',
                  }}
                >
                  Login
                </Nav.Link>
                <Nav.Link
                  as={Link}
                  to="/register"
                  onClick={() => setExpanded(false)}
                  style={{
                    color: '#2e7d32',
                    background: 'white',
                    borderRadius: '10px',
                    padding: '0.4rem 1rem',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    transition: 'all 0.2s ease',
                  }}
                >
                  Get Started
                </Nav.Link>
              </div>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default AppNavbar;
