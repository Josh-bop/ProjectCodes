import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { FaLeaf, FaEnvelope, FaLock, FaEye, FaEyeSlash, FaArrowRight } from 'react-icons/fa';

const Login = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });

      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data));
        toast.success(`Welcome back, ${response.data.name}!`);
        window.location.href = '/dashboard';
      } else {
        toast.error('No token received from server');
      }
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message || 'Login failed');
      } else if (error.request) {
        toast.error('Cannot reach the server. Please make sure the backend is running.');
      } else {
        toast.error('Login failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      background: 'linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%)',
    }}>
      {/* Left panel — decorative */}
      <div
        className="d-none d-lg-flex flex-column justify-content-center align-items-center"
        style={{
          width: '45%',
          background: 'linear-gradient(135deg, #1b5e20, #2e7d32)',
          padding: '3rem',
          color: 'white',
        }}
      >
        <div className="text-center fade-in-up">
          <div style={{
            background: 'rgba(255,255,255,0.15)',
            borderRadius: '20px',
            padding: '20px',
            display: 'inline-flex',
            marginBottom: '1.5rem',
          }}>
            <FaLeaf style={{ fontSize: '48px', color: '#a5d6a7' }} />
          </div>
          <h2 style={{ fontWeight: 700, fontSize: '2rem', marginBottom: '1rem' }}>
            Agri<span style={{ color: '#a5d6a7' }}>Tech</span>
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '1rem', maxWidth: '280px', lineHeight: 1.7 }}>
            Smart farming tools to help you grow better, faster, and smarter.
          </p>
          <div style={{ marginTop: '2.5rem', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {['Real-time weather insights', 'Crop growth tracking', 'Expert community forum'].map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'rgba(255,255,255,0.85)' }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#a5d6a7', flexShrink: 0 }} />
                <span style={{ fontSize: '0.9rem' }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem',
      }}>
        <div style={{ width: '100%', maxWidth: '420px' }} className="fade-in-up">
          {/* Mobile brand */}
          <div className="d-flex d-lg-none align-items-center gap-2 mb-4 justify-content-center">
            <FaLeaf style={{ color: '#2e7d32', fontSize: '24px' }} />
            <span style={{ fontWeight: 700, fontSize: '1.3rem', color: '#2e7d32' }}>AgriTech</span>
          </div>

          <div style={{
            background: 'white',
            borderRadius: '20px',
            padding: '2.5rem',
            boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
          }}>
            <h3 style={{ fontWeight: 700, color: '#1b5e20', marginBottom: '0.4rem' }}>Welcome back</h3>
            <p style={{ color: '#888', fontSize: '0.9rem', marginBottom: '2rem' }}>
              Sign in to your account to continue
            </p>

            <form onSubmit={handleSubmit}>
              {/* Email */}
              <div style={{ marginBottom: '1.25rem' }}>
                <label style={{ display: 'block', marginBottom: '6px', fontWeight: 500, fontSize: '0.875rem', color: '#444' }}>
                  Email address
                </label>
                <div style={{ position: 'relative' }}>
                  <FaEnvelope style={{
                    position: 'absolute', left: '14px', top: '50%',
                    transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '14px',
                  }} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="your@email.com"
                    style={{
                      width: '100%', padding: '11px 12px 11px 40px',
                      border: '1.5px solid #e0e0e0', borderRadius: '10px',
                      fontSize: '0.9rem', outline: 'none', transition: 'border-color 0.2s',
                    }}
                    onFocus={e => e.target.style.borderColor = '#4caf50'}
                    onBlur={e => e.target.style.borderColor = '#e0e0e0'}
                  />
                </div>
              </div>

              {/* Password */}
              <div style={{ marginBottom: '1.75rem' }}>
                <label style={{ display: 'block', marginBottom: '6px', fontWeight: 500, fontSize: '0.875rem', color: '#444' }}>
                  Password
                </label>
                <div style={{ position: 'relative' }}>
                  <FaLock style={{
                    position: 'absolute', left: '14px', top: '50%',
                    transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '14px',
                  }} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="Enter your password"
                    style={{
                      width: '100%', padding: '11px 40px 11px 40px',
                      border: '1.5px solid #e0e0e0', borderRadius: '10px',
                      fontSize: '0.9rem', outline: 'none', transition: 'border-color 0.2s',
                    }}
                    onFocus={e => e.target.style.borderColor = '#4caf50'}
                    onBlur={e => e.target.style.borderColor = '#e0e0e0'}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute', right: '12px', top: '50%',
                      transform: 'translateY(-50%)', background: 'none',
                      border: 'none', cursor: 'pointer', color: '#9e9e9e', padding: 0,
                    }}
                  >
                    {showPassword ? <FaEyeSlash size={15} /> : <FaEye size={15} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                style={{
                  width: '100%', padding: '13px',
                  background: loading ? '#ccc' : 'linear-gradient(135deg, #2e7d32, #4caf50)',
                  color: 'white', border: 'none', borderRadius: '10px',
                  fontSize: '0.95rem', fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                  transition: 'all 0.25s ease',
                  boxShadow: loading ? 'none' : '0 4px 14px rgba(46,125,50,0.3)',
                }}
              >
                {loading ? (
                  <>
                    <span style={{
                      width: 16, height: 16, border: '2px solid rgba(255,255,255,0.4)',
                      borderTopColor: 'white', borderRadius: '50%',
                      animation: 'spin 0.8s linear infinite', display: 'inline-block',
                    }} />
                    Signing in...
                  </>
                ) : (
                  <>Sign In <FaArrowRight size={13} /></>
                )}
              </button>
            </form>

            <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: '#666' }}>
              Don't have an account?{' '}
              <Link to="/register" style={{ color: '#2e7d32', fontWeight: 600, textDecoration: 'none' }}>
                Create one free
              </Link>
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default Login;
