import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Spinner, Table, Badge, ProgressBar, Button, Alert, Dropdown } from 'react-bootstrap';
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area
} from 'recharts';
import { 
  FaTractor, FaSeedling, FaChartLine, FaDollarSign, 
  FaCalendarAlt, FaLeaf, FaWater, FaTemperatureHigh,
  FaTint, FaBug, FaFlask, FaShoppingCart, FaUsers,
  FaDownload, FaSyncAlt, FaFilePdf, FaFileExcel, FaPrint
} from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { getUserCrops } from '../services/cropService';
import { getUserFarms } from '../services/farmService';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const AnalyticsPage = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [crops, setCrops] = useState([]);
  const [farms, setFarms] = useState([]);
  const [cropStages, setCropStages] = useState([]);
  const [healthData, setHealthData] = useState([]);
  const [monthlyData, setMonthlyData] = useState([]);
  const [stats, setStats] = useState({
    totalCrops: 0,
    activeCrops: 0,
    harvestedCrops: 0,
    predictedYield: 0,
    actualYield: 0,
    avgHealth: 0
  });

  const COLORS = {
    excellent: '#2e7d32',
    good: '#4caf50',
    fair: '#ff9800',
    poor: '#f44336',
    critical: '#d32f2f'
  };

  const HEALTH_SCORES = {
    excellent: 5,
    good: 4,
    fair: 3,
    poor: 2,
    critical: 1
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const cropsData = await getUserCrops();
      const farmsData = await getUserFarms();
      setCrops(cropsData);
      setFarms(farmsData);

      const harvestedCrops = cropsData.filter(c => c.growthStage === 'harvesting');
      const activeCrops = cropsData.filter(c => 
        c.growthStage !== 'harvesting' && c.growthStage !== 'fallow'
      );
      
      const avgHealth = cropsData.reduce((sum, c) => 
        sum + (HEALTH_SCORES[c.health] || 3), 0) / (cropsData.length || 1);

      setStats({
        totalCrops: cropsData.length,
        activeCrops: activeCrops.length,
        harvestedCrops: harvestedCrops.length,
        predictedYield: cropsData.reduce((sum, c) => sum + (c.predictedYield?.value || 0), 0),
        actualYield: cropsData.reduce((sum, c) => sum + (c.actualYield?.value || 0), 0),
        avgHealth: avgHealth
      });

      const stageCount = {};
      cropsData.forEach(crop => {
        stageCount[crop.growthStage] = (stageCount[crop.growthStage] || 0) + 1;
      });
      setCropStages(Object.entries(stageCount).map(([stage, count]) => ({ 
        stage: stage.charAt(0).toUpperCase() + stage.slice(1), 
        count 
      })));

      const healthCount = {
        excellent: cropsData.filter(c => c.health === 'excellent').length,
        good: cropsData.filter(c => c.health === 'good').length,
        fair: cropsData.filter(c => c.health === 'fair').length,
        poor: cropsData.filter(c => c.health === 'poor').length
      };
      setHealthData(Object.entries(healthCount).map(([health, value]) => ({ name: health, value })));

      const monthlyPlanting = {};
      cropsData.forEach(crop => {
        if (crop.plantingDate) {
          const month = new Date(crop.plantingDate).toLocaleString('default', { month: 'short' });
          monthlyPlanting[month] = (monthlyPlanting[month] || 0) + 1;
        }
      });
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      setMonthlyData(months.map(month => ({ 
        month, 
        plantings: monthlyPlanting[month] || 0 
      })));

    } catch (error) {
      console.error('Failed to fetch analytics:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  // Export as CSV (Excel compatible)
  const exportToCSV = () => {
    setExporting(true);
    try {
      if (crops.length === 0) {
        toast.warning('No data to export');
        setExporting(false);
        return;
      }

      // Prepare data for export
      const exportData = crops.map(crop => ({
        'Crop Name': crop.name,
        'Farm Name': crop.farm?.name || 'N/A',
        'Variety': crop.variety || 'N/A',
        'Growth Stage': crop.growthStage,
        'Health Status': crop.health,
        'Planted Date': new Date(crop.plantingDate).toLocaleDateString(),
        'Expected Harvest': crop.expectedHarvestDate ? new Date(crop.expectedHarvestDate).toLocaleDateString() : 'N/A',
        'Area Planted': `${crop.areaPlanted?.value || 0} ${crop.areaPlanted?.unit || ''}`,
        'Predicted Yield (kg)': crop.predictedYield?.value || 0,
        'Actual Yield (kg)': crop.actualYield?.value || 0,
        'Status': crop.growthStage === 'harvesting' ? 'Completed' : 'Active'
      }));

      // Convert to CSV
      const headers = Object.keys(exportData[0]);
      const csvRows = [];
      csvRows.push(headers.join(','));
      
      for (const row of exportData) {
        const values = headers.map(header => {
          const value = row[header];
          return `"${String(value).replace(/"/g, '""')}"`;
        });
        csvRows.push(values.join(','));
      }
      
      const csvString = csvRows.join('\n');
      const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `farm_analytics_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success(`Exported ${exportData.length} crop records to CSV!`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export report');
    } finally {
      setExporting(false);
    }
  };

  // Export as JSON
  const exportToJSON = () => {
    setExporting(true);
    try {
      if (crops.length === 0 && farms.length === 0) {
        toast.warning('No data to export');
        setExporting(false);
        return;
      }

      const exportData = {
        generatedAt: new Date().toISOString(),
        user: user?.name,
        email: user?.email,
        summary: {
          totalFarms: farms.length,
          totalCrops: stats.totalCrops,
          activeCrops: stats.activeCrops,
          harvestedCrops: stats.harvestedCrops,
          averageHealth: stats.avgHealth.toFixed(2),
          totalPredictedYield: stats.predictedYield,
          totalActualYield: stats.actualYield
        },
        crops: crops.map(crop => ({
          name: crop.name,
          farm: crop.farm?.name,
          variety: crop.variety,
          growthStage: crop.growthStage,
          health: crop.health,
          plantingDate: crop.plantingDate,
          expectedHarvestDate: crop.expectedHarvestDate,
          areaPlanted: crop.areaPlanted,
          predictedYield: crop.predictedYield,
          actualYield: crop.actualYield
        })),
        farms: farms.map(farm => ({
          name: farm.name,
          location: farm.location,
          size: farm.size,
          soilType: farm.soilType,
          irrigationType: farm.irrigationType
        }))
      };
      
      const jsonString = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `farm_analytics_${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('JSON report exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export JSON report');
    } finally {
      setExporting(false);
    }
  };

  // Print report
  const printReport = () => {
    if (crops.length === 0) {
      toast.warning('No data to print');
      return;
    }

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Farm Analytics Report - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #2e7d32; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #4caf50; color: white; }
            .summary { margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 8px; }
            .footer { margin-top: 30px; text-align: center; font-size: 12px; color: gray; }
          </style>
        </head>
        <body>
          <h1>🌾 Farm Analytics Report</h1>
          <p>Generated: ${new Date().toLocaleString()}</p>
          <p>Farmer: ${user?.name} (${user?.email})</p>
          
          <div class="summary">
            <h3>Summary Statistics</h3>
            <p><strong>Total Farms:</strong> ${farms.length}</p>
            <p><strong>Total Crops:</strong> ${stats.totalCrops}</p>
            <p><strong>Active Crops:</strong> ${stats.activeCrops}</p>
            <p><strong>Harvested Crops:</strong> ${stats.harvestedCrops}</p>
            <p><strong>Average Health Score:</strong> ${stats.avgHealth.toFixed(2)}/5</p>
            <p><strong>Total Predicted Yield:</strong> ${stats.predictedYield} kg</p>
            <p><strong>Total Actual Yield:</strong> ${stats.actualYield} kg</p>
          </div>
          
          <h3>Crops Details</h3>
          <table>
            <thead>
              <tr><th>Crop Name</th><th>Farm</th><th>Stage</th><th>Health</th><th>Planted Date</th><th>Predicted Yield</th><th>Actual Yield</th></tr>
            </thead>
            <tbody>
              ${crops.map(crop => `
                <tr>
                  <td>${crop.name}</td>
                  <td>${crop.farm?.name || 'N/A'}</td>
                  <td>${crop.growthStage}</td>
                  <td>${crop.health}</td>
                  <td>${new Date(crop.plantingDate).toLocaleDateString()}</td>
                  <td>${crop.predictedYield?.value || 0} kg</td>
                  <td>${crop.actualYield?.value || 0} kg</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="footer">Agri-Tech Farm Management System - Smart Farming Solution</div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const StatCard = ({ icon: Icon, title, value, color, bgLight }) => (
    <Card className="shadow-sm h-100 border-0" style={{ backgroundColor: bgLight || '#fff' }}>
      <Card.Body>
        <div className="d-flex justify-content-between align-items-start">
          <div>
            <p className="text-muted mb-1 small">{title}</p>
            <h3 className="mb-0 fw-bold" style={{ color: color }}>{value}</h3>
          </div>
          <div className="rounded-circle p-3" style={{ backgroundColor: `${color}20` }}>
            <Icon style={{ color: color, fontSize: '24px' }} />
          </div>
        </div>
      </Card.Body>
    </Card>
  );

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm">
          <p className="mb-0 small fw-bold">{label}</p>
          <p className="mb-0 small" style={{ color: payload[0].color }}>
            {payload[0].name}: {payload[0].value}
          </p>
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #e8f5e9', borderTopColor: '#2e7d32', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#4caf50', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading analytics...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <Container fluid className="mt-4 px-4">
        {/* Header */}
        <div className="mb-4 p-4 rounded-4 fade-in" style={{
          background: 'linear-gradient(135deg, #fff 0%, #f1f8e9 100%)',
          boxShadow: '0 2px 12px rgba(46,125,50,0.08)',
          borderLeft: '5px solid #4caf50',
        }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
              <h2 className="gradient-text mb-1" style={{ fontSize: '1.75rem', fontWeight: 700 }}>
                📊 Farm Analytics
              </h2>
              <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>
                Data-driven insights for better farming decisions
              </p>
            </div>
            <div className="d-flex gap-2">
              <Button
                variant="outline-success"
                size="sm"
                onClick={fetchAnalytics}
                disabled={loading}
                className="rounded-pill"
              >
                <FaSyncAlt className="me-1" /> Refresh
              </Button>
              <Dropdown>
                <Dropdown.Toggle variant="success" size="sm" className="btn-gradient rounded-pill" disabled={exporting || crops.length === 0}>
                  <FaDownload className="me-1" /> {exporting ? 'Exporting…' : 'Export'}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={exportToCSV}>
                    <FaFileExcel className="me-2 text-success" /> Export as CSV/Excel
                  </Dropdown.Item>
                  <Dropdown.Item onClick={exportToJSON}>
                    <FaFilePdf className="me-2 text-danger" /> Export as JSON
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={printReport}>
                    <FaPrint className="me-2 text-primary" /> Print Report
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
        </div>

        {/* If no crops, show message */}
        {crops.length === 0 && (
          <Alert variant="info" className="mb-4">
            <FaLeaf className="me-2" />
            No crops data available. Add some crops to see analytics and export reports.
          </Alert>
        )}

        {/* Stat Cards Row */}
        <Row className="g-3 mb-4">
          <Col md={3} sm={6}>
            <StatCard 
              icon={FaTractor} 
              title="Total Farms" 
              value={farms.length} 
              color="#2e7d32"
              bgLight="#e8f5e9"
            />
          </Col>
          <Col md={3} sm={6}>
            <StatCard 
              icon={FaSeedling} 
              title="Total Crops" 
              value={stats.totalCrops} 
              color="#4caf50"
              bgLight="#e8f5e9"
            />
          </Col>
          <Col md={3} sm={6}>
            <StatCard 
              icon={FaLeaf} 
              title="Active Crops" 
              value={stats.activeCrops} 
              color="#66bb6a"
              bgLight="#e8f5e9"
            />
          </Col>
          <Col md={3} sm={6}>
            <StatCard 
              icon={FaChartLine} 
              title="Crop Health Avg" 
              value={`${stats.avgHealth.toFixed(1)}/5`} 
              color="#ff9800"
              bgLight="#e8f5e9"
            />
          </Col>
        </Row>

        {/* Charts Row 1 */}
        <Row className="g-4 mb-4">
          <Col lg={6}>
            <Card className="shadow-sm h-100">
              <Card.Header className="bg-white border-0 pt-3">
                <h6 className="mb-0 fw-bold">
                  <FaChartLine className="me-2 text-success" /> Crop Growth Distribution
                </h6>
                <small className="text-muted">Number of crops by growth stage</small>
              </Card.Header>
              <Card.Body>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={cropStages} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="stage" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="count" fill="#4caf50" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={6}>
            <Card className="shadow-sm h-100">
              <Card.Header className="bg-white border-0 pt-3">
                <h6 className="mb-0 fw-bold">
                  <FaTint className="me-2 text-success" /> Crop Health Status
                </h6>
                <small className="text-muted">Overall health distribution</small>
              </Card.Header>
              <Card.Body>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={healthData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      labelLine={{ stroke: '#666', strokeWidth: 1 }}
                    >
                      {healthData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={COLORS[entry.name] || '#4caf50'} 
                          stroke="#fff"
                          strokeWidth={2}
                        />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Charts Row 2 */}
        <Row className="g-4 mb-4">
          <Col lg={6}>
            <Card className="shadow-sm h-100">
              <Card.Header className="bg-white border-0 pt-3">
                <h6 className="mb-0 fw-bold">
                  <FaCalendarAlt className="me-2 text-success" /> Monthly Planting Activity
                </h6>
                <small className="text-muted">Plantings per month</small>
              </Card.Header>
              <Card.Body>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={monthlyData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                    <defs>
                      <linearGradient id="colorPlantings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4caf50" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#4caf50" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area 
                      type="monotone" 
                      dataKey="plantings" 
                      stroke="#4caf50" 
                      fillOpacity={1} 
                      fill="url(#colorPlantings)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Card.Body>
            </Card>
          </Col>

          <Col lg={6}>
            <Card className="shadow-sm h-100">
              <Card.Header className="bg-white border-0 pt-3">
                <h6 className="mb-0 fw-bold">
                  <FaDollarSign className="me-2 text-success" /> Yield Overview
                </h6>
                <small className="text-muted">Predicted vs Actual Yield (kg)</small>
              </Card.Header>
              <Card.Body>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart 
                    data={[{ name: 'Yield', predicted: stats.predictedYield, actual: stats.actualYield }]}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="predicted" fill="#ff9800" name="Predicted Yield" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="actual" fill="#4caf50" name="Actual Yield" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Recent Crops Table */}
        <Row className="g-4">
          <Col lg={12}>
            <Card className="shadow-sm">
              <Card.Header className="bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="mb-0 fw-bold">
                    <FaSeedling className="me-2 text-success" /> Recent Crops Summary
                  </h6>
                  <small className="text-muted">Your latest crop activities</small>
                </div>
                {crops.length > 0 && (
                  <Button variant="link" size="sm" onClick={exportToCSV} className="text-success">
                    <FaDownload className="me-1" /> Export Table
                  </Button>
                )}
              </Card.Header>
              <Card.Body className="p-0">
                <div className="table-responsive">
                  <Table hover className="mb-0">
                    <thead className="bg-light">
                      <tr>
                        <th className="ps-3">Crop Name</th>
                        <th>Farm</th>
                        <th>Growth Stage</th>
                        <th>Health</th>
                        <th>Planted Date</th>
                        <th className="text-end pe-3">Predicted Yield</th>
                      </tr>
                    </thead>
                    <tbody>
                      {crops.slice(0, 5).map((crop) => (
                        <tr key={crop._id}>
                          <td className="ps-3">
                            <div className="d-flex align-items-center gap-2">
                              <FaSeedling className="text-success" />
                              <strong>{crop.name}</strong>
                            </div>
                           </td>
                          <td>{crop.farm?.name || 'N/A'}</td>
                          <td>
                            <Badge bg="secondary" className="px-2 py-1">
                              {crop.growthStage}
                            </Badge>
                          </td>
                          <td>
                            <Badge 
                              bg={crop.health === 'excellent' ? 'success' : 
                                  crop.health === 'good' ? 'info' : 
                                  crop.health === 'fair' ? 'warning' : 'danger'}
                              className="px-2 py-1"
                            >
                              {crop.health}
                            </Badge>
                          </td>
                          <td>{new Date(crop.plantingDate).toLocaleDateString()}</td>
                          <td className="text-end pe-3">{crop.predictedYield?.value || 0} kg</td>
                        </tr>
                      ))}
                      {crops.length === 0 && (
                        <tr>
                          <td colSpan="6" className="text-center py-4 text-muted">
                            No crops added yet. Start by adding your first crop!
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Health Indicators and Tips */}
        <Row className="g-4 mt-2">
          <Col lg={12}>
            <Card className="gradient-bg text-white">
              <Card.Body className="py-4">
                <div className="text-center mb-3">
                  <FaLeaf size={32} />
                  <h5 className="mt-2 mb-0">Smart Farming Insights</h5>
                </div>
                <Row className="mt-3">
                  <Col md={4} className="text-center mb-3 mb-md-0">
                    <FaTemperatureHigh size={24} className="mb-2" />
                    <p className="mb-0 small">
                      {stats.avgHealth > 4 ? '✨ Your crops are in excellent condition!' :
                       stats.avgHealth > 3 ? '🌿 Your crops are doing well. Keep monitoring.' :
                       '⚠️ Some crops need attention. Check health alerts.'}
                    </p>
                  </Col>
                  <Col md={4} className="text-center mb-3 mb-md-0">
                    <FaTractor size={24} className="mb-2" />
                    <p className="mb-0 small">
                      You have {stats.activeCrops} active crops across {farms.length} farms
                    </p>
                  </Col>
                  <Col md={4} className="text-center">
                    <FaWater size={24} className="mb-2" />
                    <p className="mb-0 small">
                      {stats.avgHealth > 3 ? 'Maintain current irrigation schedule' : 'Consider increasing irrigation frequency'}
                    </p>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
      <Footer />

      <style>{`
        .gradient-bg {
          background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
        }
        .gradient-text {
          background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </>
  );
};

export default AnalyticsPage;