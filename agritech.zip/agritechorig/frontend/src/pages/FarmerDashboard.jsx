import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Spinner, Alert } from 'react-bootstrap';
import { 
  FaTractor, FaSeedling, FaChartLine, FaUsers, 
  FaLeaf, FaComments, FaStore, FaCloudSun,
  FaArrowRight, FaCheckCircle, FaExclamationTriangle,
  FaWater, FaTemperatureHigh, FaCalendarAlt, FaPlus,
  FaTasks, FaBell, FaRocket
} from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import WeatherWidget from '../components/Dashboard/WeatherWidget';

const FarmerDashboard = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [stats, setStats] = useState({
    farms: 0,
    crops: 0,
    activeCrops: 0,
    alerts: 0
  });
  const [loading, setLoading] = useState(true);
  const [recentCrops, setRecentCrops] = useState([]);
  const [recentAlerts, setRecentAlerts] = useState([]);

  const getAuthHeaders = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    fetchDashboardData();
  }, [isAuthenticated, navigate]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [farmsRes, cropsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/farms', getAuthHeaders()),
        axios.get('http://localhost:5000/api/crops', getAuthHeaders())
      ]);

      const farms = farmsRes.data || [];
      const crops = cropsRes.data || [];
      const activeCrops = crops.filter(c => 
        c.growthStage !== 'harvesting' && c.growthStage !== 'fallow'
      ).length;
      
      const allAlerts = crops.flatMap(crop => 
        (crop.alerts || []).map(alert => ({ ...alert, cropName: crop.name }))
      ).slice(0, 3);

      setStats({
        farms: farms.length,
        crops: crops.length,
        activeCrops: activeCrops,
        alerts: allAlerts.length
      });
      setRecentCrops(crops.slice(0, 4));
      setRecentAlerts(allAlerts);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { icon: <FaTractor size={28} />, title: 'Total Farms', value: stats.farms, link: '/farms', bg: '#e8f5e9', color: '#2e7d32' },
    { icon: <FaSeedling size={28} />, title: 'Total Crops', value: stats.crops, link: '/crops', bg: '#e8f5e9', color: '#4caf50' },
    { icon: <FaLeaf size={28} />, title: 'Active Crops', value: stats.activeCrops, link: '/crops', bg: '#e8f5e9', color: '#66bb6a' },
    { icon: <FaExclamationTriangle size={28} />, title: 'Active Alerts', value: stats.alerts, link: '/crops', bg: '#fff3e0', color: '#ff9800' },
  ];

  const quickActions = [
    { name: 'Add Farm', icon: <FaTractor />, link: '/farms', color: '#2e7d32', bg: '#e8f5e9' },
    { name: 'Add Crop', icon: <FaSeedling />, link: '/crops', color: '#4caf50', bg: '#e8f5e9' },
    { name: 'Visit Forum', icon: <FaComments />, link: '/forum', color: '#7b1fa2', bg: '#f3e5f5' },
    { name: 'Marketplace', icon: <FaStore />, link: '/marketplace', color: '#f57c00', bg: '#fff3e0' },
  ];

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #e8f5e9', borderTopColor: '#2e7d32', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#4caf50', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading dashboard...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <Container fluid className="mt-4 px-4 pb-2">
        {/* Welcome Section */}
        <div className="mb-4 p-4 rounded-4 fade-in" style={{
          background: 'linear-gradient(135deg, #fff 0%, #f1f8e9 100%)',
          boxShadow: '0 2px 12px rgba(46,125,50,0.08)',
          borderLeft: '5px solid #4caf50',
        }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
              <h2 className="gradient-text mb-1" style={{ fontSize: '1.75rem', fontWeight: 700 }}>
                Welcome back, {user?.name?.split(' ')[0] || 'Farmer'}! 
              </h2>
              <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>
                Here's what's happening with your farm today
              </p>
            </div>
            <div className="d-flex gap-2">
              <Button as={Link} to="/farms" variant="outline-success" className="rounded-pill" size="sm">
                <FaTractor className="me-2" /> Manage Farms
              </Button>
              <Button as={Link} to="/crops" variant="success" className="rounded-pill btn-gradient" size="sm">
                <FaPlus className="me-2" /> Add Crop
              </Button>
            </div>
          </div>
        </div>

        {/* Stat Cards */}
        <Row className="g-3 mb-4">
          {statCards.map((card, idx) => (
            <Col md={3} sm={6} key={idx}>
              <Card
                className="border-0 shadow-sm h-100 card-hover"
                style={{ cursor: 'pointer', borderRadius: '16px' }}
                onClick={() => navigate(card.link)}
              >
                <Card.Body className="p-3">
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <div className="mb-2 p-2 rounded-3 d-inline-flex" style={{ backgroundColor: card.bg }}>
                        <div style={{ color: card.color }}>{card.icon}</div>
                      </div>
                      <p className="text-muted mb-1" style={{ fontSize: '0.8rem', fontWeight: 500 }}>{card.title}</p>
                      <h3 className="mb-0 fw-bold" style={{ color: card.color, fontSize: '1.8rem' }}>{card.value}</h3>
                    </div>
                    <div style={{
                      background: card.bg, borderRadius: '8px', padding: '6px 8px',
                      display: 'flex', alignItems: 'center',
                    }}>
                      <FaArrowRight style={{ color: card.color, fontSize: '12px' }} />
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Top Row: Quick Actions and Recent Alerts (side by side) */}
        <Row className="g-4 mb-4">
          {/* Quick Actions Card - Left */}
          <Col lg={6}>
            <Card className="border-0 shadow-sm h-100" style={{ 
              borderRadius: '16px', 
              overflow: 'hidden',
              background: 'linear-gradient(135deg, #f8fff8 0%, #f1f8e9 100%)'
            }}>
              <Card.Header className="bg-white border-0 pt-4 pb-2" style={{ backgroundColor: 'transparent !important' }}>
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle" style={{ backgroundColor: '#e8f5e9' }}>
                    <FaTasks style={{ color: '#2e7d32', fontSize: '18px' }} />
                  </div>
                  <h5 className="mb-0 fw-bold" style={{ color: '#2e7d32' }}>Quick Actions</h5>
                </div>
              </Card.Header>
              <Card.Body>
                <Row className="g-3">
                  {quickActions.map((action, idx) => (
                    <Col sm={6} key={idx}>
                      <Button 
                        as={Link} 
                        to={action.link}
                        variant="light" 
                        className="w-100 py-3 border-0 rounded-3"
                        style={{ 
                          backgroundColor: action.bg,
                          transition: 'all 0.3s ease'
                        }}
                      >
                        <div style={{ color: action.color, fontSize: '24px' }} className="mb-2">{action.icon}</div>
                        <small className="fw-bold" style={{ color: action.color }}>{action.name}</small>
                      </Button>
                    </Col>
                  ))}
                </Row>
              </Card.Body>
            </Card>
          </Col>

          {/* Recent Alerts Card - Right */}
          <Col lg={6}>
            <Card className="border-0 shadow-sm h-100" style={{ 
              borderRadius: '16px', 
              overflow: 'hidden',
              background: 'linear-gradient(135deg, #fff8e1 0%, #fff3e0 100%)'
            }}>
              <Card.Header className="bg-white border-0 pt-4 pb-2" style={{ backgroundColor: 'transparent !important' }}>
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle" style={{ backgroundColor: '#fff3e0' }}>
                    <FaBell style={{ color: '#ff9800', fontSize: '18px' }} />
                  </div>
                  <h5 className="mb-0 fw-bold" style={{ color: '#e65100' }}>Recent Alerts</h5>
                </div>
              </Card.Header>
              <Card.Body>
                {recentAlerts.length === 0 ? (
                  <div className="text-center py-4">
                    <FaCheckCircle size={48} style={{ color: '#4caf50' }} />
                    <p className="text-muted mt-2 mb-0">No new alerts. Your crops are doing well!</p>
                  </div>
                ) : (
                  recentAlerts.map((alert, idx) => (
                    <div key={idx} className="d-flex align-items-start gap-2 mb-3 p-3 rounded-3" style={{ 
                      backgroundColor: '#ffffff',
                      borderRadius: '12px',
                      borderLeft: '4px solid #ff9800'
                    }}>
                      <FaExclamationTriangle style={{ color: '#ff9800', fontSize: '16px', marginTop: '2px' }} />
                      <div>
                        <div className="small fw-bold" style={{ color: '#e65100' }}>{alert.cropName}</div>
                        <div className="small text-muted">{alert.message || alert.type}</div>
                        <small className="text-muted">
                          {alert.date ? new Date(alert.date).toLocaleDateString() : 'Recently'}
                        </small>
                      </div>
                    </div>
                  ))
                )}
                {stats.alerts > 0 && (
                  <Button variant="link" size="sm" className="p-0 mt-2" as={Link} to="/crops" style={{ color: '#ff9800' }}>
                    View all alerts <FaArrowRight className="ms-1" />
                  </Button>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Bottom Row: Weather Widget (Landscape/Full Width) */}
        <Row className="g-4 mb-4">
          <Col lg={12}>
            <div style={{ width: '100%' }}>
              <WeatherWidget />
            </div>
          </Col>
        </Row>

        {/* Recent Crops Section - Full Width */}
        <Row className="mt-2">
          <Col lg={12}>
            <Card className="border-0 shadow-sm" style={{ borderRadius: '16px', overflow: 'hidden' }}>
              <Card.Header className="bg-white border-0 pt-4 pb-2 d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle d-inline-flex" style={{ backgroundColor: '#e8f5e9' }}>
                    <FaSeedling style={{ color: '#4caf50', fontSize: '16px' }} />
                  </div>
                  <h5 className="mb-0" style={{ color: '#2e7d32' }}>🌱 Recent Crops</h5>
                </div>
                <Button as={Link} to="/crops" variant="link" size="sm" className="text-success">
                  View All <FaArrowRight className="ms-1" />
                </Button>
              </Card.Header>
              <Card.Body>
                {recentCrops.length === 0 ? (
                  <div className="text-center py-4">
                    <FaSeedling size={40} className="text-muted mb-2" />
                    <p className="text-muted mb-0">No crops added yet.</p>
                    <Button as={Link} to="/crops" variant="success" size="sm" className="mt-3 btn-gradient">
                      <FaPlus className="me-2" /> Add Your First Crop
                    </Button>
                  </div>
                ) : (
                  <Row className="g-3">
                    {recentCrops.map((crop) => (
                      <Col md={6} lg={3} key={crop._id}>
                        <Card className="border-0" style={{ backgroundColor: '#f8f9fa', borderRadius: '12px' }}>
                          <Card.Body className="p-3">
                            <div className="d-flex align-items-center gap-2 mb-2">
                              <FaSeedling style={{ color: '#4caf50' }} />
                              <strong>{crop.name}</strong>
                            </div>
                            <div className="small text-muted">
                              <div>Stage: <span className="text-capitalize">{crop.growthStage}</span></div>
                              <div>Health: <span style={{ color: crop.health === 'good' ? '#4caf50' : crop.health === 'excellent' ? '#2e7d32' : '#ff9800' }}>{crop.health}</span></div>
                              <div>Planted: {new Date(crop.plantingDate).toLocaleDateString()}</div>
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    ))}
                  </Row>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Farming Tips - Full Width */}
        <Row className="mt-4 mb-4">
          <Col lg={12}>
            <div className="gradient-bg text-white rounded-4 p-4" style={{ borderRadius: '16px' }}>
              <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div className="d-flex align-items-center gap-3">
                  <FaRocket size={32} className="opacity-75" />
                  <div>
                    <h5 className="mb-1">Farming Tip of the Day</h5>
                    <p className="mb-0 small opacity-90">Regular soil testing helps optimize fertilizer usage and improve crop yields.</p>
                  </div>
                </div>
                <Button as={Link} to="/forum" variant="light" size="sm" className="rounded-pill">
                  <FaComments className="me-2" /> Discuss with Experts
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .gradient-bg {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
        }
        .btn-gradient {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          border: none;
        }
        .btn-gradient:hover {
          background: linear-gradient(135deg, #1b5e20, #2e7d32);
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </>
  );
};

export default FarmerDashboard;