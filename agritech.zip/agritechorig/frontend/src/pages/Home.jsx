import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { 
  FaLeaf, FaChartLine, FaComments, FaCloudSun, FaTractor, 
  FaShieldAlt, FaSeedling, FaUsers, FaHeadset, FaRocket,
  FaArrowRight, FaCheckCircle, FaStar, FaUserGraduate,
  FaRegSmile, FaHandHoldingHeart
} from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

// Import local image (you can replace this with your image URL)
// If you have the image locally, put it in src/assets/ and import it
// import farmHeroImage from '../assets/agri11.jpg';

const Home = () => {
  const heroImageUrl = "/src/assets/homeAgri.jpg";

  const features = [
    { icon: <FaTractor size={32} style={{ color: '#2e7d32' }} />, title: 'Farm Management', desc: 'Track your farms, crops, and resources in one place', color: '#e8f5e9' },
    { icon: <FaCloudSun size={32} style={{ color: '#0288d1' }} />, title: 'Weather Insights', desc: 'Real-time weather with agricultural recommendations', color: '#e1f5fe' },
    { icon: <FaChartLine size={32} style={{ color: '#f57c00' }} />, title: 'Analytics', desc: 'Data-driven decisions for better yields', color: '#fff3e0' },
    { icon: <FaComments size={32} style={{ color: '#7b1fa2' }} />, title: 'Community Forum', desc: 'Connect with experts and fellow farmers', color: '#f3e5f5' },
    { icon: <FaSeedling size={32} style={{ color: '#558b2f' }} />, title: 'Expert Advice', desc: 'Get guidance from agricultural experts', color: '#f1f8e9' },
    { icon: <FaShieldAlt size={32} style={{ color: '#1565c0' }} />, title: 'Secure Platform', desc: 'Your data is safe with role-based access', color: '#e8eaf6' },
  ];

  const stats = [
    { number: '10K+', label: 'Active Farmers',   icon: <FaUsers       style={{ color: '#2e7d32' }} /> },
    { number: '500+', label: 'Expert Advisors',  icon: <FaUserGraduate style={{ color: '#ff9800' }} /> },
    { number: '50K+', label: 'Crops Tracked',    icon: <FaSeedling    style={{ color: '#4caf50' }} /> },
    { number: '98%',  label: 'Satisfaction Rate', icon: <FaStar        style={{ color: '#ffc107' }} /> },
  ];
  return (
    <>
      <Navbar />
      
      {/* Hero Section */}
      <div className="hero-section" style={{ 
        background: 'linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%)',
        padding: '80px 0',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <Container>
          <Row className="align-items-center">
            <Col lg={6} className="mb-5 mb-lg-0">
              <div className="fade-in-up">
                <div className="d-flex align-items-center gap-2 mb-3">
                  <FaLeaf size={40} style={{ color: '#2e7d32' }} />
                  <span style={{ 
                    background: 'rgba(46, 125, 50, 0.15)', 
                    padding: '4px 12px', 
                    borderRadius: '20px',
                    fontSize: '14px',
                    color: '#2e7d32',
                    fontWeight: 500
                  }}>
                    Smart Farming Solution
                  </span>
                </div>
                <h1 className="display-3 fw-bold mb-4" style={{ 
                  background: 'linear-gradient(135deg, #1b5e20, #4caf50)',
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                  color: 'transparent'
                }}>
                  Smart Farming for Modern Agriculture
                </h1>
                <p className="lead text-muted mb-4" style={{ fontSize: '1.25rem' }}>
                  Empower your farming journey with real-time data, expert insights, and community support. 
                  Make evidence-based decisions and maximize your agricultural productivity.
                </p>
                <div className="d-flex flex-wrap gap-3">
                  <Button as={Link} to="/register" size="lg" className="btn-gradient px-4">
                    Get Started Free <FaArrowRight className="ms-2" />
                  </Button>
                  <Button as={Link} to="/login" variant="outline-success" size="lg">
                    Login
                  </Button>
                </div>
                <div className="d-flex align-items-center gap-3 mt-4">
                  <FaCheckCircle style={{ color: '#2e7d32' }} />
                  <span className="small text-muted">Free forever • No credit card required</span>
                </div>
              </div>
            </Col>
            <Col lg={6} className="text-center">
              <div style={{ position: 'relative' }}>
                <img 
                  src={heroImageUrl}
                  alt="Smart Farming" 
                  className="img-fluid rounded-4 shadow-lg"
                  style={{ 
                    maxHeight: '450px', 
                    objectFit: 'cover', 
                    width: '100%',
                    borderRadius: '20px'
                  }}
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "https://images.unsplash.com/photo-1592982537447-2f6c6a7a9f5c?w=600&h=400&fit=crop";
                  }}
                />
                <div style={{
                  position: 'absolute',
                  bottom: '20px',
                  left: '20px',
                  background: 'white',
                  borderRadius: '12px',
                  padding: '12px 20px',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
                }}>
                  <div className="d-flex align-items-center gap-3">
                    <FaLeaf style={{ color: '#2e7d32', fontSize: '24px' }} />
                    <div>
                      <div className="fw-bold">Trusted by</div>
                      <div className="small text-muted">10,000+ farmers</div>
                    </div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>

      {/* Stats Section */}
      <Container className="py-5">
        <Row className="g-4 justify-content-center">
          {stats.map((stat, idx) => (
            <Col md={3} sm={6} key={idx}>
              <Card className="text-center border-0 shadow-sm card-hover">
                <Card.Body className="py-4">
                  <div className="mb-3">{stat.icon}</div>
                  <h2 className="mb-0 fw-bold" style={{ color: '#2e7d32' }}>{stat.number}</h2>
                  <p className="text-muted mb-0">{stat.label}</p>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Features Section */}
      <Container className="py-5">
        <div className="text-center mb-5">
          <h2 className="gradient-text fw-bold">Powerful Features for Smart Farmers</h2>
          <p className="text-muted">Everything you need to manage your farm efficiently</p>
        </div>
        <Row className="g-4">
          {features.map((feature, idx) => (
            <Col md={6} lg={4} key={idx}>
              <Card className="h-100 border-0 shadow-sm card-hover">
                <Card.Body className="p-4">
                  <div className="mb-3 p-3 rounded-circle d-inline-flex" style={{ backgroundColor: feature.color }}>
                    {feature.icon}
                  </div>
                  <Card.Title className="h5 mb-2">{feature.title}</Card.Title>
                  <Card.Text className="text-muted">{feature.desc}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* CTA Section */}
      <div className="gradient-bg text-white py-5 mt-5">
        <Container className="text-center">
          <FaRocket size={48} className="mb-3 opacity-75" />
          <h2 className="mb-3 fw-bold">Ready to Transform Your Farming?</h2>
          <p className="lead mb-4 opacity-90">Join thousands of farmers already using Agri-Tech</p>
          <Button as={Link} to="/register" variant="light" size="lg" className="px-5 py-2 fw-bold">
            Get Started Now <FaArrowRight className="ms-2" />
          </Button>
        </Container>
      </div>
      <Footer />

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .fade-in-up { animation: fadeInUp 0.6s ease-out; }
        .gradient-text {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .gradient-bg { background: linear-gradient(135deg, #2e7d32, #4caf50); }
        .btn-gradient {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          border: none;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-gradient:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 15px rgba(46, 125, 50, 0.3);
        }
        .card-hover { transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
      `}</style>
    </>
  );
};

export default Home;