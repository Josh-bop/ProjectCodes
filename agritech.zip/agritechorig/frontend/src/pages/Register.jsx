import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { FaLeaf, FaUser, FaEnvelope, FaLock, FaPhone, FaEye, FaEyeSlash, FaArrowRight, FaCheckCircle } from 'react-icons/fa';

const InputField = ({ icon: Icon, label, type = 'text', name, value, onChange, placeholder, required, extra }) => {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ marginBottom: '1rem' }}>
      <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500, fontSize: '0.85rem', color: '#444' }}>
        {label} {required && <span style={{ color: '#f44336' }}>*</span>}
      </label>
      <div style={{ position: 'relative' }}>
        {Icon && (
          <Icon style={{
            position: 'absolute', left: '13px', top: '50%',
            transform: 'translateY(-50%)', color: focused ? '#4caf50' : '#9e9e9e', fontSize: '13px',
            transition: 'color 0.2s',
          }} />
        )}
        <input
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          required={required}
          placeholder={placeholder}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: '100%',
            padding: `10px 12px 10px ${Icon ? '36px' : '12px'}`,
            border: `1.5px solid ${focused ? '#4caf50' : '#e0e0e0'}`,
            borderRadius: '10px', fontSize: '0.875rem', outline: 'none',
            transition: 'border-color 0.2s',
            boxShadow: focused ? '0 0 0 3px rgba(76,175,80,0.12)' : 'none',
          }}
        />
        {extra}
      </div>
    </div>
  );
};

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', confirmPassword: '', phone: '', role: 'farmer',
  });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const passwordStrength = () => {
    const p = formData.password;
    if (!p) return null;
    if (p.length < 6) return { label: 'Too short', color: '#f44336', width: '25%' };
    if (p.length < 8) return { label: 'Weak', color: '#ff9800', width: '50%' };
    if (/[A-Z]/.test(p) && /[0-9]/.test(p)) return { label: 'Strong', color: '#2e7d32', width: '100%' };
    return { label: 'Fair', color: '#66bb6a', width: '75%' };
  };

  const strength = passwordStrength();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        phone: formData.phone,
        role: formData.role,
      });
      toast.success('Account created! Please sign in.');
      navigate('/login');
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message || 'Registration failed');
      } else if (error.request) {
        toast.error('Cannot reach the server. Please make sure the backend is running.');
      } else {
        toast.error('Registration failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%)',
      padding: '2rem 1rem',
    }}>
      <div style={{ width: '100%', maxWidth: '500px' }} className="fade-in-up">
        {/* Brand */}
        <div className="d-flex align-items-center gap-2 mb-4 justify-content-center">
          <div style={{ background: '#2e7d32', borderRadius: '10px', padding: '8px 10px', display: 'inline-flex' }}>
            <FaLeaf style={{ color: '#a5d6a7', fontSize: '20px' }} />
          </div>
          <span style={{ fontWeight: 700, fontSize: '1.4rem', color: '#1b5e20' }}>
            Agri<span style={{ color: '#4caf50' }}>Tech</span>
          </span>
        </div>

        <div style={{
          background: 'white',
          borderRadius: '20px',
          padding: '2.5rem',
          boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
        }}>
          <h3 style={{ fontWeight: 700, color: '#1b5e20', marginBottom: '0.3rem' }}>Create your account</h3>
          <p style={{ color: '#888', fontSize: '0.875rem', marginBottom: '1.75rem' }}>
            Join thousands of farmers using AgriTech
          </p>

          <form onSubmit={handleSubmit}>
            <InputField icon={FaUser} label="Full Name" name="name" value={formData.name} onChange={handleChange} placeholder="Your full name" required />
            <InputField icon={FaEnvelope} label="Email" type="email" name="email" value={formData.email} onChange={handleChange} placeholder="your@email.com" required />

            {/* Password with toggle */}
            <div style={{ marginBottom: '0.5rem' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500, fontSize: '0.85rem', color: '#444' }}>
                Password <span style={{ color: '#f44336' }}>*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <FaLock style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '13px' }} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  placeholder="Minimum 6 characters"
                  style={{
                    width: '100%', padding: '10px 40px 10px 36px',
                    border: '1.5px solid #e0e0e0', borderRadius: '10px',
                    fontSize: '0.875rem', outline: 'none',
                  }}
                  onFocus={e => { e.target.style.borderColor = '#4caf50'; e.target.style.boxShadow = '0 0 0 3px rgba(76,175,80,0.12)'; }}
                  onBlur={e => { e.target.style.borderColor = '#e0e0e0'; e.target.style.boxShadow = 'none'; }}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9e9e9e', padding: 0 }}>
                  {showPassword ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
              </div>
            </div>

            {/* Password strength */}
            {strength && (
              <div style={{ marginBottom: '1rem' }}>
                <div style={{ height: 4, background: '#f0f0f0', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: strength.width, background: strength.color, borderRadius: 4, transition: 'width 0.3s ease' }} />
                </div>
                <small style={{ color: strength.color, fontSize: '0.75rem' }}>{strength.label} password</small>
              </div>
            )}

            {/* Confirm password */}
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 500, fontSize: '0.85rem', color: '#444' }}>
                Confirm Password <span style={{ color: '#f44336' }}>*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <FaLock style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '13px' }} />
                <input
                  type={showConfirm ? 'text' : 'password'}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  placeholder="Repeat your password"
                  style={{
                    width: '100%', padding: '10px 40px 10px 36px',
                    border: `1.5px solid ${formData.confirmPassword && formData.confirmPassword !== formData.password ? '#f44336' : '#e0e0e0'}`,
                    borderRadius: '10px', fontSize: '0.875rem', outline: 'none',
                  }}
                  onFocus={e => { e.target.style.borderColor = '#4caf50'; }}
                  onBlur={e => { e.target.style.borderColor = formData.confirmPassword && formData.confirmPassword !== formData.password ? '#f44336' : '#e0e0e0'; }}
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                  style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9e9e9e', padding: 0 }}>
                  {showConfirm ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
                {formData.confirmPassword && formData.confirmPassword === formData.password && (
                  <FaCheckCircle style={{ position: 'absolute', right: '36px', top: '50%', transform: 'translateY(-50%)', color: '#4caf50', fontSize: '13px' }} />
                )}
              </div>
            </div>

            <InputField icon={FaPhone} label="Phone Number" type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="Optional" />

            {/* Role selector */}
            <div style={{ marginBottom: '1.75rem' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500, fontSize: '0.85rem', color: '#444' }}>
                I am a...
              </label>
              <div style={{ display: 'flex', gap: '10px' }}>
                {[
                  { value: 'farmer', label: '🌾 Farmer', desc: 'Manage my farm' },
                  { value: 'expert', label: '👨‍🌾 Expert', desc: 'Advise farmers' },
                ].map(opt => (
                  <label
                    key={opt.value}
                    style={{
                      flex: 1, cursor: 'pointer',
                      border: `2px solid ${formData.role === opt.value ? '#4caf50' : '#e0e0e0'}`,
                      borderRadius: '12px', padding: '12px',
                      background: formData.role === opt.value ? '#f1f8e9' : 'white',
                      transition: 'all 0.2s ease',
                      textAlign: 'center',
                    }}
                  >
                    <input
                      type="radio"
                      name="role"
                      value={opt.value}
                      checked={formData.role === opt.value}
                      onChange={handleChange}
                      style={{ display: 'none' }}
                    />
                    <div style={{ fontWeight: 600, fontSize: '0.9rem', color: formData.role === opt.value ? '#2e7d32' : '#555' }}>
                      {opt.label}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: '#888', marginTop: '2px' }}>{opt.desc}</div>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%', padding: '13px',
                background: loading ? '#ccc' : 'linear-gradient(135deg, #2e7d32, #4caf50)',
                color: 'white', border: 'none', borderRadius: '10px',
                fontSize: '0.95rem', fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                boxShadow: loading ? 'none' : '0 4px 14px rgba(46,125,50,0.3)',
                transition: 'all 0.25s ease',
              }}
            >
              {loading ? (
                <>
                  <span style={{
                    width: 16, height: 16, border: '2px solid rgba(255,255,255,0.4)',
                    borderTopColor: 'white', borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite', display: 'inline-block',
                  }} />
                  Creating account...
                </>
              ) : (
                <>Create Account <FaArrowRight size={13} /></>
              )}
            </button>
          </form>

          <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: '#666' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: '#2e7d32', fontWeight: 600, textDecoration: 'none' }}>
              Sign in
            </Link>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default Register;
