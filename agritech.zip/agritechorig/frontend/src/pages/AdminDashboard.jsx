import React, { useState, useEffect, useRef } from 'react';
import { Container, Row, Col, Card, Table, Badge, Button, Modal, Form, InputGroup, Alert } from 'react-bootstrap';
import {
  FaUsers, FaTractor, FaSeedling, FaDollarSign, FaEdit, FaTrash,
  FaLeaf, FaShieldAlt, FaChartBar, FaShoppingCart, FaComments,
  FaSearch, FaEye, FaCheck, FaTimes, FaPlus, FaStore,
  FaUserCheck, FaUserTimes, FaBan, FaSyncAlt, FaBoxOpen,
  FaClipboardList, FaHome, FaSignOutAlt, FaImage, FaUpload, FaTimesCircle
} from 'react-icons/fa';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  getSystemStats, getAllUsers, updateUser, deleteUser,
  getAllBookings, updateBookingStatus,
  getAllProductsAdmin, getAllForumPosts, deleteForumPost,
  getAllFarmsAdmin, getAllCropsAdmin,
} from '../services/adminService';
import { createProduct, updateProduct, deleteProduct } from '../services/productService';
import { toast } from 'react-toastify';
import moment from 'moment';

// ── Shared helpers ──────────────────────────────────────────────────────────
const Spinner = () => (
  <div style={{ position: 'relative', width: 40, height: 40 }}>
    <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #e8f5e9', borderTopColor: '#2e7d32', animation: 'spin 0.9s linear infinite' }} />
    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <FaLeaf style={{ color: '#4caf50', fontSize: '14px' }} />
    </div>
  </div>
);

const SectionLoader = ({ text = 'Loading...' }) => (
  <div className="d-flex flex-column align-items-center justify-content-center py-5 gap-3">
    <Spinner /><p className="text-muted mb-0" style={{ fontSize: '0.875rem' }}>{text}</p>
  </div>
);

const EmptyState = ({ icon, title, sub }) => (
  <div className="text-center py-5">
    <div style={{ fontSize: 40, marginBottom: 12 }}>{icon}</div>
    <h6 style={{ color: '#2e7d32' }}>{title}</h6>
    {sub && <p className="text-muted small mb-0">{sub}</p>}
  </div>
);

const roleBadge = (role) => {
  const map = { admin: ['danger','👑'], expert: ['info','👨‍🌾'], farmer: ['success','🌾'] };
  const [bg, emoji] = map[role] || ['secondary','?'];
  return <Badge bg={bg}>{emoji} {role}</Badge>;
};

const statusBadge = (status) => {
  const map = { pending:'warning', confirmed:'info', in_progress:'primary', completed:'success', cancelled:'danger', refunded:'secondary' };
  return <Badge bg={map[status] || 'secondary'}>{status?.replace('_',' ')}</Badge>;
};

const payBadge = (s) => {
  const map = { pending:'warning', paid:'success', failed:'danger', refunded:'secondary' };
  return <Badge bg={map[s] || 'secondary'}>{s}</Badge>;
};

const healthBadge = (h) => {
  const map = { excellent:'success', good:'info', fair:'warning', poor:'danger', critical:'danger' };
  return <Badge bg={map[h] || 'secondary'}>{h}</Badge>;
};

// ── Sidebar nav items ────────────────────────────────────────────────────────
const NAV = [
  { key: 'overview',  label: 'Overview',    icon: <FaChartBar /> },
  { key: 'users',     label: 'Users',       icon: <FaUsers /> },
  { key: 'farms',     label: 'Farms',       icon: <FaTractor /> },
  { key: 'crops',     label: 'Crops',       icon: <FaSeedling /> },
  { key: 'products',  label: 'Products',    icon: <FaStore /> },
  { key: 'bookings',  label: 'Bookings',    icon: <FaShoppingCart /> },
  { key: 'forum',     label: 'Forum',       icon: <FaComments /> },
];

// ── Main Component ───────────────────────────────────────────────────────────
const AdminDashboard = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats]         = useState(null);
  const [users, setUsers]         = useState([]);
  const [farms, setFarms]         = useState([]);
  const [crops, setCrops]         = useState([]);
  const [products, setProducts]   = useState([]);
  const [bookings, setBookings]   = useState([]);
  const [forum, setForum]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [tabLoading, setTabLoading] = useState(false);
  const [search, setSearch]       = useState('');

  // Modals
  const [userModal, setUserModal]       = useState(false);
  const [editingUser, setEditingUser]   = useState(null);
  const [userForm, setUserForm]         = useState({ name:'', email:'', role:'farmer', isVerified:false });
  const [productModal, setProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [productForm, setProductForm]   = useState({ name:'', category:'seeds', description:'', price:'', unit:'kg', stock:'', manufacturer:'', isAvailable:true, images:[] });
  const [imageUploading, setImageUploading] = useState(false);
  const imageInputRef = useRef(null);
  const [bookingModal, setBookingModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState(null);
  const [bookingForm, setBookingForm]   = useState({ status:'pending', paymentStatus:'pending' });
  const [viewUserModal, setViewUserModal] = useState(false);
  const [viewingUser, setViewingUser]   = useState(null);
  const [createUserModal, setCreateUserModal] = useState(false);
  const [createUserForm, setCreateUserForm]   = useState({ name:'', email:'', password:'', role:'farmer', isVerified:false });

  useEffect(() => { fetchOverview(); }, []);
  useEffect(() => { fetchTab(activeTab); }, [activeTab]);

  const fetchOverview = async () => {
    setLoading(true);
    try {
      const s = await getSystemStats();
      setStats(s);
    } catch { toast.error('Failed to load stats'); }
    finally { setLoading(false); }
  };

  const fetchTab = async (tab) => {
    setTabLoading(true);
    try {
      if (tab === 'users')    setUsers(await getAllUsers());
      if (tab === 'farms')    setFarms(await getAllFarmsAdmin());
      if (tab === 'crops')    setCrops(await getAllCropsAdmin());
      if (tab === 'products') setProducts(await getAllProductsAdmin());
      if (tab === 'bookings') setBookings(await getAllBookings());
      if (tab === 'forum')    setForum(await getAllForumPosts());
      if (tab === 'overview') { const s = await getSystemStats(); setStats(s); }
    } catch { toast.error(`Failed to load ${tab}`); }
    finally { setTabLoading(false); }
  };

  // ── User handlers ──
  const openEditUser = (u) => { setEditingUser(u); setUserForm({ name:u.name, email:u.email, role:u.role, isVerified:u.isVerified }); setUserModal(true); };
  const handleSaveUser = async (e) => {
    e.preventDefault();
    try { await updateUser(editingUser._id, userForm); toast.success('User updated'); setUserModal(false); fetchTab('users'); }
    catch (err) { toast.error(err.response?.data?.message || 'Failed to update user'); }
  };
  const handleDeleteUser = async (id) => {
    if (!window.confirm('Delete this user and all their data?')) return;
    try { await deleteUser(id); toast.success('User deleted'); fetchTab('users'); }
    catch { toast.error('Failed to delete user'); }
  };
  const handleViewUser = (u) => { setViewingUser(u); setViewUserModal(true); };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        name: createUserForm.name,
        email: createUserForm.email,
        password: createUserForm.password,
        role: createUserForm.role,
      }, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } });
      // If admin wants it verified immediately, update via admin endpoint
      if (createUserForm.isVerified) {
        const allUsers = await getAllUsers();
        const newUser = allUsers.find(u => u.email === createUserForm.email);
        if (newUser) await updateUser(newUser._id, { isVerified: true });
      }
      toast.success(`Account created for ${createUserForm.name}`);
      setCreateUserModal(false);
      setCreateUserForm({ name:'', email:'', password:'', role:'farmer', isVerified:false });
      fetchTab('users');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create account');
    }
  };

  // ── Product handlers ──
  const openAddProduct = () => {
    setEditingProduct(null);
    setProductForm({ name:'', category:'seeds', description:'', price:'', unit:'kg', stock:'', manufacturer:'', isAvailable:true, images:[] });
    setProductModal(true);
  };
  const openEditProduct = (p) => {
    setEditingProduct(p);
    setProductForm({ name:p.name, category:p.category, description:p.description, price:p.price, unit:p.unit, stock:p.stock, manufacturer:p.manufacturer||'', isAvailable:p.isAvailable, images:p.images||[] });
    setProductModal(true);
  };

  const handleProductImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Image must be under 5MB'); return; }
    setImageUploading(true);
    try {
      const formData = new FormData();
      formData.append('image', file);
      const res = await axios.post('http://localhost:5000/api/upload/single', formData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}`, 'Content-Type': 'multipart/form-data' },
      });
      if (res.data.success) {
        setProductForm(prev => ({ ...prev, images: [...prev.images, res.data.url] }));
        toast.success('Image uploaded');
      }
    } catch { toast.error('Image upload failed'); }
    finally { setImageUploading(false); if (imageInputRef.current) imageInputRef.current.value = ''; }
  };

  const removeProductImage = (idx) => {
    setProductForm(prev => ({ ...prev, images: prev.images.filter((_,i) => i !== idx) }));
  };
  const handleSaveProduct = async (e) => {
    e.preventDefault();
    try {
      if (editingProduct) { await updateProduct(editingProduct._id, productForm); toast.success('Product updated'); }
      else { await createProduct(productForm); toast.success('Product created'); }
      setProductModal(false); fetchTab('products');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save product'); }
  };
  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try { await deleteProduct(id); toast.success('Product deleted'); fetchTab('products'); }
    catch { toast.error('Failed to delete product'); }
  };

  // ── Booking handlers ──
  const openEditBooking = (b) => { setEditingBooking(b); setBookingForm({ status:b.status, paymentStatus:b.paymentStatus }); setBookingModal(true); };
  const handleSaveBooking = async (e) => {
    e.preventDefault();
    try { await updateBookingStatus(editingBooking._id, bookingForm); toast.success('Booking updated'); setBookingModal(false); fetchTab('bookings'); }
    catch { toast.error('Failed to update booking'); }
  };

  // ── Forum handlers ──
  const handleDeletePost = async (id) => {
    if (!window.confirm('Delete this forum post and all its comments?')) return;
    try { await deleteForumPost(id); toast.success('Post deleted'); fetchTab('forum'); }
    catch { toast.error('Failed to delete post'); }
  };

  const filter = (arr, keys) => arr.filter(item => keys.some(k => String(item[k]||'').toLowerCase().includes(search.toLowerCase())));

  if (loading) return (
    <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight:'100vh', gap:'1rem', background:'#f8fdf8' }}>
      <Spinner /><p className="text-muted" style={{ fontSize:'0.9rem' }}>Loading admin panel...</p>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  // ── Stat cards data ──
  const statCards = [
    { icon:<FaUsers size={22}/>,       label:'Total Users',   value:stats?.users?.total||0,           color:'#2e7d32', bg:'#e8f5e9' },
    { icon:<FaTractor size={22}/>,     label:'Farmers',       value:stats?.users?.farmers||0,         color:'#1976d2', bg:'#e3f2fd' },
    { icon:<FaUserCheck size={22}/>,   label:'Experts',       value:stats?.users?.experts||0,         color:'#7b1fa2', bg:'#f3e5f5' },
    { icon:<FaTractor size={22}/>,     label:'Total Farms',   value:stats?.agriculture?.farms||0,     color:'#f57c00', bg:'#fff3e0' },
    { icon:<FaSeedling size={22}/>,    label:'Total Crops',   value:stats?.agriculture?.crops||0,     color:'#388e3c', bg:'#e8f5e9' },
    { icon:<FaStore size={22}/>,       label:'Products',      value:stats?.commerce?.products||0,     color:'#0288d1', bg:'#e1f5fe' },
    { icon:<FaShoppingCart size={22}/>,label:'Bookings',      value:stats?.commerce?.bookings||0,     color:'#e64a19', bg:'#fbe9e7' },
    { icon:<FaDollarSign size={22}/>,  label:'Revenue',       value:`₱${(stats?.commerce?.revenue||0).toLocaleString()}`, color:'#2e7d32', bg:'#e8f5e9' },
  ];

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#f4f7f4' }}>
      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        .admin-nav-btn{display:flex;align-items:center;gap:10px;width:100%;padding:10px 16px;border:none;border-radius:10px;cursor:pointer;font-size:0.875rem;font-weight:500;transition:all 0.2s ease;text-align:left;background:transparent;color:#555;}
        .admin-nav-btn:hover{background:#f1f8e9;color:#2e7d32;}
        .admin-nav-btn.active{background:linear-gradient(135deg,#2e7d32,#4caf50);color:white;box-shadow:0 4px 12px rgba(46,125,50,0.3);}
        .admin-table th{font-size:0.75rem;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#888;border-bottom:2px solid #f0f0f0!important;padding:12px 16px!important;}
        .admin-table td{font-size:0.875rem;vertical-align:middle;padding:12px 16px!important;border-bottom:1px solid #f8f8f8!important;}
        .admin-table tbody tr:hover{background:#f9fdf9;}
        .section-card{background:white;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);overflow:hidden;}
      `}</style>

      {/* ── Sidebar ── */}
      <div style={{ width:240, background:'white', borderRight:'1px solid #f0f0f0', display:'flex', flexDirection:'column', position:'sticky', top:0, height:'100vh', flexShrink:0 }}>
        {/* Brand */}
        <div style={{ padding:'24px 20px 16px', borderBottom:'1px solid #f0f0f0' }}>
          <div className="d-flex align-items-center gap-2">
            <div style={{ background:'linear-gradient(135deg,#2e7d32,#4caf50)', borderRadius:10, padding:'8px 10px', display:'flex' }}>
              <FaLeaf style={{ color:'white', fontSize:18 }} />
            </div>
            <div>
              <div style={{ fontWeight:700, fontSize:'1rem', color:'#1b5e20' }}>AgriTech</div>
              <div style={{ fontSize:'0.7rem', color:'#888', marginTop:-2 }}>Admin Panel</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, padding:'12px 12px', overflowY:'auto' }}>
          <p style={{ fontSize:'0.7rem', fontWeight:600, color:'#aaa', textTransform:'uppercase', letterSpacing:'0.5px', padding:'0 4px', marginBottom:8 }}>Management</p>
          {NAV.map(n => (
            <button key={n.key} className={`admin-nav-btn${activeTab===n.key?' active':''}`} onClick={() => setActiveTab(n.key)}>
              <span style={{ fontSize:15 }}>{n.icon}</span>{n.label}
            </button>
          ))}
        </nav>

        {/* Bottom actions */}
        <div style={{ padding:'12px', borderTop:'1px solid #f0f0f0' }}>
          <button className="admin-nav-btn" onClick={() => navigate('/dashboard')} style={{ marginBottom:4 }}>
            <FaHome size={14} /> Back to App
          </button>
          <button className="admin-nav-btn" onClick={() => { logout(); navigate('/login'); }} style={{ color:'#f44336' }}>
            <FaSignOutAlt size={14} /> Sign Out
          </button>
        </div>
      </div>

      {/* ── Main content ── */}
      <div style={{ flex:1, overflowY:'auto', padding:'28px 28px' }}>

        {/* Top bar */}
        <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
          <div>
            <h4 style={{ fontWeight:700, color:'#1b5e20', marginBottom:2 }}>
              {NAV.find(n=>n.key===activeTab)?.label || 'Overview'}
            </h4>
            <p className="text-muted mb-0" style={{ fontSize:'0.8rem' }}>
              {new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}
            </p>
          </div>
          <div className="d-flex gap-2 align-items-center">
            {activeTab !== 'overview' && (
              <div style={{ position:'relative' }}>
                <FaSearch style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#aaa', fontSize:12 }} />
                <input
                  placeholder={`Search ${activeTab}...`}
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  style={{ padding:'8px 12px 8px 32px', border:'1.5px solid #e0e0e0', borderRadius:10, fontSize:'0.85rem', outline:'none', width:220 }}
                  onFocus={e=>{e.target.style.borderColor='#4caf50';e.target.style.boxShadow='0 0 0 3px rgba(76,175,80,0.12)'}}
                  onBlur={e=>{e.target.style.borderColor='#e0e0e0';e.target.style.boxShadow='none'}}
                />
              </div>
            )}
            <button onClick={() => fetchTab(activeTab)} style={{ background:'#f1f8e9', border:'none', borderRadius:10, padding:'8px 14px', cursor:'pointer', color:'#2e7d32', fontSize:'0.85rem', display:'flex', alignItems:'center', gap:6 }}>
              <FaSyncAlt size={12} /> Refresh
            </button>
            {activeTab === 'products' && (
              <button onClick={openAddProduct} style={{ background:'linear-gradient(135deg,#2e7d32,#4caf50)', border:'none', borderRadius:10, padding:'8px 16px', cursor:'pointer', color:'white', fontSize:'0.85rem', fontWeight:600, display:'flex', alignItems:'center', gap:6 }}>
                <FaPlus size={12} /> Add Product
              </button>
            )}
            {activeTab === 'users' && (
              <button onClick={() => setCreateUserModal(true)} style={{ background:'linear-gradient(135deg,#1976d2,#42a5f5)', border:'none', borderRadius:10, padding:'8px 16px', cursor:'pointer', color:'white', fontSize:'0.85rem', fontWeight:600, display:'flex', alignItems:'center', gap:6 }}>
                <FaPlus size={12} /> Create Account
              </button>
            )}
          </div>
        </div>

        {tabLoading ? <SectionLoader /> : (
          <>
            {/* ══ OVERVIEW ══ */}
            {activeTab === 'overview' && (
              <>
                <Row className="g-3 mb-4">
                  {statCards.map((c,i) => (
                    <Col md={3} sm={6} key={i}>
                      <div className="section-card p-4">
                        <div className="d-flex justify-content-between align-items-start">
                          <div>
                            <p style={{ fontSize:'0.75rem', fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'0.4px', marginBottom:4 }}>{c.label}</p>
                            <h3 style={{ fontWeight:700, color:c.color, marginBottom:0, fontSize:'1.8rem' }}>{c.value}</h3>
                          </div>
                          <div style={{ background:c.bg, borderRadius:12, padding:'10px 12px', color:c.color }}>{c.icon}</div>
                        </div>
                      </div>
                    </Col>
                  ))}
                </Row>

                <Row className="g-4">
                  <Col lg={6}>
                    <div className="section-card">
                      <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                        <FaUsers style={{ color:'#2e7d32' }} />
                        <span style={{ fontWeight:600, fontSize:'0.95rem' }}>Recent Users</span>
                      </div>
                      <div style={{ padding:'8px 0' }}>
                        {(stats?.recentActivity?.users||[]).slice(0,5).map(u => (
                          <div key={u._id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 20px', borderBottom:'1px solid #fafafa' }}>
                            <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,#e8f5e9,#c8e6c9)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                              <FaUsers style={{ color:'#4caf50', fontSize:14 }} />
                            </div>
                            <div style={{ flex:1, minWidth:0 }}>
                              <div style={{ fontWeight:600, fontSize:'0.875rem', color:'#333' }}>{u.name}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{u.email}</div>
                            </div>
                            {roleBadge(u.role)}
                          </div>
                        ))}
                        {!(stats?.recentActivity?.users?.length) && <EmptyState icon="👥" title="No users yet" />}
                      </div>
                    </div>
                  </Col>
                  <Col lg={6}>
                    <div className="section-card">
                      <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                        <FaShoppingCart style={{ color:'#e64a19' }} />
                        <span style={{ fontWeight:600, fontSize:'0.95rem' }}>Recent Bookings</span>
                      </div>
                      <div style={{ padding:'8px 0' }}>
                        {(stats?.recentActivity?.bookings||[]).slice(0,5).map(b => (
                          <div key={b._id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 20px', borderBottom:'1px solid #fafafa' }}>
                            <div style={{ flex:1, minWidth:0 }}>
                              <div style={{ fontWeight:600, fontSize:'0.875rem', color:'#333' }}>{b.user?.name||'Unknown'}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{b.bookingType?.replace(/_/g,' ')} · ₱{b.totalAmount}</div>
                            </div>
                            {statusBadge(b.status)}
                          </div>
                        ))}
                        {!(stats?.recentActivity?.bookings?.length) && <EmptyState icon="🛒" title="No bookings yet" />}
                      </div>
                    </div>
                  </Col>
                </Row>
              </>
            )}

            {/* ══ USERS ══ */}
            {activeTab === 'users' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaUsers style={{ color:'#2e7d32' }} />
                  <span style={{ fontWeight:600 }}>All Users</span>
                  <span style={{ marginLeft:'auto', background:'#e8f5e9', color:'#2e7d32', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{users.length}</span>
                </div>
                {filter(users,['name','email','role']).length === 0
                  ? <EmptyState icon="👥" title="No users found" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th>Last Login</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(users,['name','email','role']).map(u => (
                          <tr key={u._id}>
                            <td>
                              <div style={{ fontWeight:600, color:'#333' }}>{u.name}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{u.email}</div>
                            </td>
                            <td>{roleBadge(u.role)}</td>
                            <td><Badge bg={u.isVerified?'success':'warning'}>{u.isVerified?'✓ Verified':'Pending'}</Badge></td>
                            <td style={{ color:'#666' }}>{moment(u.createdAt).format('MMM D, YYYY')}</td>
                            <td style={{ color:'#666' }}>{u.lastLogin ? moment(u.lastLogin).fromNow() : '—'}</td>
                            <td>
                              <div className="d-flex gap-1">
                                <button onClick={() => handleViewUser(u)} style={{ background:'#e3f2fd', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#1976d2' }} title="View"><FaEye size={12}/></button>
                                <button onClick={() => openEditUser(u)} style={{ background:'#e8f5e9', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#2e7d32' }} title="Edit"><FaEdit size={12}/></button>
                                <button onClick={() => handleDeleteUser(u._id)} style={{ background:'#ffebee', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#f44336' }} title="Delete"><FaTrash size={12}/></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ══ FARMS ══ */}
            {activeTab === 'farms' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaTractor style={{ color:'#f57c00' }} />
                  <span style={{ fontWeight:600 }}>All Farms</span>
                  <span style={{ marginLeft:'auto', background:'#fff3e0', color:'#f57c00', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{farms.length}</span>
                </div>
                {filter(farms,['name']).length === 0
                  ? <EmptyState icon="🚜" title="No farms found" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>Farm Name</th><th>Owner</th><th>Location</th><th>Size</th><th>Soil Type</th><th>Irrigation</th><th>Created</th></tr></thead>
                      <tbody>
                        {filter(farms,['name']).map(f => (
                          <tr key={f._id}>
                            <td style={{ fontWeight:600, color:'#333' }}>{f.name}</td>
                            <td>
                              <div style={{ fontWeight:500 }}>{f.user?.name||'—'}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{f.user?.email||''}</div>
                            </td>
                            <td style={{ color:'#666' }}>{[f.location?.city, f.location?.state].filter(Boolean).join(', ')||'—'}</td>
                            <td style={{ color:'#666' }}>{f.size?.value ? `${f.size.value} ${f.size.unit}` : '—'}</td>
                            <td><Badge bg="secondary">{f.soilType||'—'}</Badge></td>
                            <td style={{ color:'#666', textTransform:'capitalize' }}>{f.irrigationType||'—'}</td>
                            <td style={{ color:'#666' }}>{moment(f.createdAt).format('MMM D, YYYY')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ══ CROPS ══ */}
            {activeTab === 'crops' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaSeedling style={{ color:'#388e3c' }} />
                  <span style={{ fontWeight:600 }}>All Crops</span>
                  <span style={{ marginLeft:'auto', background:'#e8f5e9', color:'#388e3c', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{crops.length}</span>
                </div>
                {filter(crops,['name','variety']).length === 0
                  ? <EmptyState icon="🌾" title="No crops found" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>Crop</th><th>Farmer</th><th>Farm</th><th>Stage</th><th>Health</th><th>Planted</th><th>Harvest</th></tr></thead>
                      <tbody>
                        {filter(crops,['name','variety']).map(c => (
                          <tr key={c._id}>
                            <td>
                              <div style={{ fontWeight:600, color:'#333' }}>{c.name}</div>
                              {c.variety && <div style={{ fontSize:'0.75rem', color:'#888' }}>{c.variety}</div>}
                            </td>
                            <td style={{ color:'#666' }}>{c.user?.name||'—'}</td>
                            <td style={{ color:'#666' }}>{c.farm?.name||'—'}</td>
                            <td><Badge bg="secondary" style={{ textTransform:'capitalize' }}>{c.growthStage}</Badge></td>
                            <td>{healthBadge(c.health)}</td>
                            <td style={{ color:'#666' }}>{moment(c.plantingDate).format('MMM D, YYYY')}</td>
                            <td style={{ color:'#666' }}>{c.expectedHarvestDate ? moment(c.expectedHarvestDate).format('MMM D, YYYY') : '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ══ PRODUCTS ══ */}
            {activeTab === 'products' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaStore style={{ color:'#0288d1' }} />
                  <span style={{ fontWeight:600 }}>All Products</span>
                  <span style={{ marginLeft:'auto', background:'#e1f5fe', color:'#0288d1', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{products.length}</span>
                </div>
                {filter(products,['name','category']).length === 0
                  ? <EmptyState icon="📦" title="No products yet" sub="Click 'Add Product' to create one" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>Image</th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(products,['name','category']).map(p => (
                          <tr key={p._id}>
                            <td>
                              {p.images?.[0] ? (
                                <img
                                  src={p.images[0].startsWith('/uploads/') ? `http://localhost:5000${p.images[0]}` : p.images[0]}
                                  alt={p.name}
                                  style={{ width:48, height:48, objectFit:'cover', borderRadius:8, border:'1px solid #f0f0f0' }}
                                />
                              ) : (
                                <div style={{ width:48, height:48, borderRadius:8, background:'#f5f5f5', display:'flex', alignItems:'center', justifyContent:'center' }}>
                                  <FaImage style={{ color:'#ccc', fontSize:18 }} />
                                </div>
                              )}
                            </td>
                            <td>
                              <div style={{ fontWeight:600, color:'#333' }}>{p.name}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{p.manufacturer||''}</div>
                            </td>
                            <td><Badge bg="info">{p.category}</Badge></td>
                            <td style={{ fontWeight:600, color:'#2e7d32' }}>₱{p.price}/{p.unit}</td>
                            <td style={{ color: p.stock===0?'#f44336':'#333' }}>{p.stock} {p.unit}s</td>
                            <td style={{ color:'#ff9800' }}>{'★'.repeat(Math.round(p.rating||0))} {p.rating?.toFixed(1)||'—'}</td>
                            <td><Badge bg={p.isAvailable?'success':'secondary'}>{p.isAvailable?'Available':'Hidden'}</Badge></td>
                            <td>
                              <div className="d-flex gap-1">
                                <button onClick={() => openEditProduct(p)} style={{ background:'#e8f5e9', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#2e7d32' }}><FaEdit size={12}/></button>
                                <button onClick={() => handleDeleteProduct(p._id)} style={{ background:'#ffebee', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#f44336' }}><FaTrash size={12}/></button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ══ BOOKINGS ══ */}
            {activeTab === 'bookings' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaShoppingCart style={{ color:'#e64a19' }} />
                  <span style={{ fontWeight:600 }}>All Bookings</span>
                  <span style={{ marginLeft:'auto', background:'#fbe9e7', color:'#e64a19', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{bookings.length}</span>
                </div>
                {filter(bookings,['bookingType']).length === 0
                  ? <EmptyState icon="🛒" title="No bookings yet" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>Customer</th><th>Type</th><th>Product</th><th>Amount</th><th>Status</th><th>Payment</th><th>Date</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(bookings,['bookingType']).map(b => (
                          <tr key={b._id}>
                            <td>
                              <div style={{ fontWeight:600, color:'#333' }}>{b.user?.name||'—'}</div>
                              <div style={{ fontSize:'0.75rem', color:'#888' }}>{b.user?.email||''}</div>
                            </td>
                            <td style={{ color:'#666', textTransform:'capitalize', fontSize:'0.8rem' }}>{b.bookingType?.replace(/_/g,' ')}</td>
                            <td style={{ color:'#666' }}>{b.product?.name||'—'}</td>
                            <td style={{ fontWeight:600, color:'#2e7d32' }}>₱{b.totalAmount}</td>
                            <td>{statusBadge(b.status)}</td>
                            <td>{payBadge(b.paymentStatus)}</td>
                            <td style={{ color:'#666' }}>{moment(b.createdAt).format('MMM D, YYYY')}</td>
                            <td>
                              <button onClick={() => openEditBooking(b)} style={{ background:'#e8f5e9', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#2e7d32' }}><FaEdit size={12}/></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ══ FORUM ══ */}
            {activeTab === 'forum' && (
              <div className="section-card">
                <div style={{ padding:'16px 20px', borderBottom:'1px solid #f0f0f0', display:'flex', alignItems:'center', gap:8 }}>
                  <FaComments style={{ color:'#7b1fa2' }} />
                  <span style={{ fontWeight:600 }}>Forum Posts</span>
                  <span style={{ marginLeft:'auto', background:'#f3e5f5', color:'#7b1fa2', borderRadius:20, padding:'2px 12px', fontSize:'0.8rem', fontWeight:600 }}>{forum.length}</span>
                </div>
                {filter(forum,['title','category']).length === 0
                  ? <EmptyState icon="💬" title="No forum posts yet" />
                  : (
                  <div style={{ overflowX:'auto' }}>
                    <table className="table admin-table mb-0">
                      <thead><tr><th>Title</th><th>Author</th><th>Category</th><th>Likes</th><th>Views</th><th>Status</th><th>Posted</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filter(forum,['title','category']).map(p => (
                          <tr key={p._id}>
                            <td style={{ maxWidth:220 }}>
                              <div style={{ fontWeight:600, color:'#333', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.title}</div>
                            </td>
                            <td style={{ color:'#666' }}>{p.user?.name||'—'}</td>
                            <td><Badge bg="secondary">{p.category||'general'}</Badge></td>
                            <td style={{ color:'#666' }}>{p.likes?.length||0}</td>
                            <td style={{ color:'#666' }}>{p.views||0}</td>
                            <td><Badge bg={p.isResolved?'success':'warning'}>{p.isResolved?'Resolved':'Open'}</Badge></td>
                            <td style={{ color:'#666' }}>{moment(p.createdAt).format('MMM D, YYYY')}</td>
                            <td>
                              <button onClick={() => handleDeletePost(p._id)} style={{ background:'#ffebee', border:'none', borderRadius:8, padding:'5px 8px', cursor:'pointer', color:'#f44336' }}><FaTrash size={12}/></button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* ══ MODALS ══ */}

      {/* Create Account */}
      <Modal show={createUserModal} onHide={() => setCreateUserModal(false)} centered>
        <Modal.Header closeButton style={{ background:'linear-gradient(135deg,#1976d2,#42a5f5)', color:'white' }}>
          <Modal.Title style={{ fontSize:'1rem', fontWeight:600 }}>
            <FaPlus className="me-2" size={14} />Create New Account
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleCreateUser}>
          <Modal.Body className="p-4">
            <Form.Group className="mb-3">
              <Form.Label>Full Name <span style={{color:'#f44336'}}>*</span></Form.Label>
              <Form.Control
                value={createUserForm.name}
                onChange={e => setCreateUserForm({...createUserForm, name:e.target.value})}
                required placeholder="e.g. Juan dela Cruz"
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email Address <span style={{color:'#f44336'}}>*</span></Form.Label>
              <Form.Control
                type="email"
                value={createUserForm.email}
                onChange={e => setCreateUserForm({...createUserForm, email:e.target.value})}
                required placeholder="user@email.com"
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password <span style={{color:'#f44336'}}>*</span></Form.Label>
              <Form.Control
                type="password"
                value={createUserForm.password}
                onChange={e => setCreateUserForm({...createUserForm, password:e.target.value})}
                required placeholder="Minimum 6 characters"
                minLength={6}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Role</Form.Label>
              <Form.Select
                value={createUserForm.role}
                onChange={e => setCreateUserForm({...createUserForm, role:e.target.value})}
              >
                <option value="farmer">🌾 Farmer</option>
                <option value="expert">👨‍🌾 Expert</option>
                <option value="admin">👑 Admin</option>
              </Form.Select>
            </Form.Group>
            <Form.Check
              type="switch"
              label="Mark as Verified immediately"
              checked={createUserForm.isVerified}
              onChange={e => setCreateUserForm({...createUserForm, isVerified:e.target.checked})}
            />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="light" onClick={() => setCreateUserModal(false)}>Cancel</Button>
            <Button type="submit" style={{ background:'linear-gradient(135deg,#1976d2,#42a5f5)', border:'none' }}>
              Create Account
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Edit User */}
      <Modal show={userModal} onHide={() => setUserModal(false)} centered>
        <Modal.Header closeButton style={{ background:'linear-gradient(135deg,#2e7d32,#4caf50)', color:'white' }}>
          <Modal.Title style={{ fontSize:'1rem', fontWeight:600 }}>Edit User</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSaveUser}>
          <Modal.Body className="p-4">
            <Form.Group className="mb-3"><Form.Label>Full Name</Form.Label>
              <Form.Control value={userForm.name} onChange={e=>setUserForm({...userForm,name:e.target.value})} required />
            </Form.Group>
            <Form.Group className="mb-3"><Form.Label>Email</Form.Label>
              <Form.Control type="email" value={userForm.email} onChange={e=>setUserForm({...userForm,email:e.target.value})} required />
            </Form.Group>
            <Form.Group className="mb-3"><Form.Label>Role</Form.Label>
              <Form.Select value={userForm.role} onChange={e=>setUserForm({...userForm,role:e.target.value})}>
                <option value="farmer">🌾 Farmer</option>
                <option value="expert">👨‍🌾 Expert</option>
                <option value="admin">👑 Admin</option>
              </Form.Select>
            </Form.Group>
            <Form.Check type="switch" label="Account Verified" checked={userForm.isVerified} onChange={e=>setUserForm({...userForm,isVerified:e.target.checked})} />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="light" onClick={() => setUserModal(false)}>Cancel</Button>
            <Button type="submit" variant="success">Save Changes</Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* View User */}
      <Modal show={viewUserModal} onHide={() => setViewUserModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title style={{ fontSize:'1rem', fontWeight:600 }}>User Details</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-4">
          {viewingUser && (
            <div>
              <div className="text-center mb-4">
                <div style={{ width:64, height:64, borderRadius:'50%', background:'linear-gradient(135deg,#e8f5e9,#c8e6c9)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 12px' }}>
                  <FaUsers style={{ color:'#4caf50', fontSize:28 }} />
                </div>
                <h5 style={{ fontWeight:700, marginBottom:4 }}>{viewingUser.name}</h5>
                {roleBadge(viewingUser.role)}
              </div>
              {[
                ['Email', viewingUser.email],
                ['Phone', viewingUser.phone||'—'],
                ['Status', viewingUser.isVerified ? '✓ Verified' : 'Pending'],
                ['Joined', moment(viewingUser.createdAt).format('MMMM D, YYYY')],
                ['Last Login', viewingUser.lastLogin ? moment(viewingUser.lastLogin).fromNow() : '—'],
                ['Location', [viewingUser.location?.city, viewingUser.location?.state].filter(Boolean).join(', ')||'—'],
                ['Experience', viewingUser.farmExperience||'—'],
              ].map(([k,v]) => (
                <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:'1px solid #f5f5f5' }}>
                  <span style={{ color:'#888', fontSize:'0.875rem' }}>{k}</span>
                  <span style={{ fontWeight:500, fontSize:'0.875rem' }}>{v}</span>
                </div>
              ))}
              {viewingUser.bio && <div style={{ marginTop:12, padding:12, background:'#f9f9f9', borderRadius:10, fontSize:'0.875rem', color:'#555' }}>{viewingUser.bio}</div>}
            </div>
          )}
        </Modal.Body>
      </Modal>

      {/* Edit/Add Product */}
      <Modal show={productModal} onHide={() => setProductModal(false)} size="lg" centered>
        <Modal.Header closeButton style={{ background:'linear-gradient(135deg,#2e7d32,#4caf50)', color:'white' }}>
          <Modal.Title style={{ fontSize:'1rem', fontWeight:600 }}>{editingProduct ? '✏️ Edit Product' : '➕ Add New Product'}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSaveProduct}>
          <Modal.Body className="p-4">
            <Row>
              <Col md={8}><Form.Group className="mb-3"><Form.Label>Product Name <span style={{color:'#f44336'}}>*</span></Form.Label>
                <Form.Control value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})} required placeholder="e.g. Hybrid Rice Seeds" />
              </Form.Group></Col>
              <Col md={4}><Form.Group className="mb-3"><Form.Label>Category <span style={{color:'#f44336'}}>*</span></Form.Label>
                <Form.Select value={productForm.category} onChange={e=>setProductForm({...productForm,category:e.target.value})}>
                  {['seeds','fertilizers','pesticides','herbicides','equipment','tools','other'].map(c=><option key={c} value={c}>{c}</option>)}
                </Form.Select>
              </Form.Group></Col>
            </Row>

            <Form.Group className="mb-3"><Form.Label>Description <span style={{color:'#f44336'}}>*</span></Form.Label>
              <Form.Control as="textarea" rows={3} value={productForm.description} onChange={e=>setProductForm({...productForm,description:e.target.value})} required placeholder="Describe the product..." />
            </Form.Group>

            <Row>
              <Col md={4}><Form.Group className="mb-3"><Form.Label>Price (₱) <span style={{color:'#f44336'}}>*</span></Form.Label>
                <Form.Control type="number" step="0.01" min="0" value={productForm.price} onChange={e=>setProductForm({...productForm,price:e.target.value})} required placeholder="0.00" />
              </Form.Group></Col>
              <Col md={4}><Form.Group className="mb-3"><Form.Label>Unit</Form.Label>
                <Form.Select value={productForm.unit} onChange={e=>setProductForm({...productForm,unit:e.target.value})}>
                  {['kg','g','liter','ml','piece','bag','bottle'].map(u=><option key={u} value={u}>{u}</option>)}
                </Form.Select>
              </Form.Group></Col>
              <Col md={4}><Form.Group className="mb-3"><Form.Label>Stock <span style={{color:'#f44336'}}>*</span></Form.Label>
                <Form.Control type="number" min="0" value={productForm.stock} onChange={e=>setProductForm({...productForm,stock:e.target.value})} required placeholder="0" />
              </Form.Group></Col>
            </Row>

            <Form.Group className="mb-3"><Form.Label>Manufacturer</Form.Label>
              <Form.Control value={productForm.manufacturer} onChange={e=>setProductForm({...productForm,manufacturer:e.target.value})} placeholder="Optional" />
            </Form.Group>

            {/* ── Image Upload Section ── */}
            <Form.Group className="mb-3">
              <Form.Label className="d-flex align-items-center gap-2">
                <FaImage style={{ color:'#2e7d32' }} /> Product Images
                <span style={{ fontSize:'0.75rem', color:'#888', fontWeight:400 }}>(JPG, PNG, WebP · max 5MB each)</span>
              </Form.Label>

              {/* Upload button */}
              <div
                onClick={() => !imageUploading && imageInputRef.current?.click()}
                style={{
                  border: '2px dashed #c8e6c9',
                  borderRadius: 12,
                  padding: '20px',
                  textAlign: 'center',
                  cursor: imageUploading ? 'not-allowed' : 'pointer',
                  background: imageUploading ? '#f9f9f9' : '#f9fdf9',
                  transition: 'all 0.2s ease',
                  marginBottom: 12,
                }}
                onMouseEnter={e => { if (!imageUploading) e.currentTarget.style.borderColor = '#4caf50'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = '#c8e6c9'; }}
              >
                {imageUploading ? (
                  <div className="d-flex align-items-center justify-content-center gap-2">
                    <div style={{ width:18, height:18, border:'2px solid #e0e0e0', borderTopColor:'#2e7d32', borderRadius:'50%', animation:'spin 0.8s linear infinite' }} />
                    <span style={{ color:'#888', fontSize:'0.875rem' }}>Uploading...</span>
                  </div>
                ) : (
                  <>
                    <FaUpload style={{ color:'#4caf50', fontSize:24, marginBottom:8 }} />
                    <div style={{ fontWeight:600, color:'#2e7d32', fontSize:'0.9rem' }}>Click to upload image</div>
                    <div style={{ color:'#aaa', fontSize:'0.78rem', marginTop:2 }}>or drag and drop here</div>
                  </>
                )}
              </div>
              <input
                ref={imageInputRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                onChange={handleProductImageUpload}
                style={{ display:'none' }}
              />

              {/* Image previews */}
              {productForm.images.length > 0 && (
                <div style={{ display:'flex', flexWrap:'wrap', gap:10, marginTop:4 }}>
                  {productForm.images.map((url, idx) => (
                    <div key={idx} style={{ position:'relative', width:90, height:90, borderRadius:10, overflow:'hidden', border:'2px solid #e8f5e9', flexShrink:0 }}>
                      <img
                        src={url.startsWith('/uploads/') ? `http://localhost:5000${url}` : url}
                        alt={`product-${idx}`}
                        style={{ width:'100%', height:'100%', objectFit:'cover' }}
                      />
                      {/* Remove button */}
                      <button
                        type="button"
                        onClick={() => removeProductImage(idx)}
                        style={{
                          position:'absolute', top:4, right:4,
                          background:'rgba(244,67,54,0.85)', border:'none',
                          borderRadius:'50%', width:22, height:22,
                          display:'flex', alignItems:'center', justifyContent:'center',
                          cursor:'pointer', color:'white', padding:0,
                        }}
                        title="Remove image"
                      >
                        <FaTimesCircle size={12} />
                      </button>
                      {/* Primary badge */}
                      {idx === 0 && (
                        <div style={{ position:'absolute', bottom:0, left:0, right:0, background:'rgba(46,125,50,0.8)', color:'white', fontSize:'0.65rem', textAlign:'center', padding:'2px 0', fontWeight:600 }}>
                          MAIN
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {productForm.images.length === 0 && (
                <p style={{ color:'#aaa', fontSize:'0.78rem', marginTop:4, marginBottom:0 }}>No images added yet. The first image will be shown as the main product photo.</p>
              )}
            </Form.Group>

            <Form.Check type="switch" label="Available for purchase" checked={productForm.isAvailable} onChange={e=>setProductForm({...productForm,isAvailable:e.target.checked})} />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="light" onClick={() => setProductModal(false)}>Cancel</Button>
            <Button type="submit" variant="success" style={{ background:'linear-gradient(135deg,#2e7d32,#4caf50)', border:'none' }}>
              {editingProduct ? 'Update Product' : 'Create Product'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Edit Booking */}
      <Modal show={bookingModal} onHide={() => setBookingModal(false)} centered>
        <Modal.Header closeButton style={{ background:'linear-gradient(135deg,#e64a19,#ff7043)', color:'white' }}>
          <Modal.Title style={{ fontSize:'1rem', fontWeight:600 }}>Update Booking Status</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSaveBooking}>
          <Modal.Body className="p-4">
            {editingBooking && (
              <Alert variant="light" style={{ background:'#f9f9f9', border:'1px solid #f0f0f0', borderRadius:10, marginBottom:16 }}>
                <div style={{ fontSize:'0.875rem' }}>
                  <strong>{editingBooking.user?.name}</strong> · {editingBooking.bookingType?.replace(/_/g,' ')} · <strong>₱{editingBooking.totalAmount}</strong>
                </div>
              </Alert>
            )}
            <Form.Group className="mb-3"><Form.Label>Order Status</Form.Label>
              <Form.Select value={bookingForm.status} onChange={e=>setBookingForm({...bookingForm,status:e.target.value})}>
                {['pending','confirmed','in_progress','completed','cancelled','refunded'].map(s=><option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
              </Form.Select>
            </Form.Group>
            <Form.Group><Form.Label>Payment Status</Form.Label>
              <Form.Select value={bookingForm.paymentStatus} onChange={e=>setBookingForm({...bookingForm,paymentStatus:e.target.value})}>
                {['pending','paid','failed','refunded'].map(s=><option key={s} value={s}>{s}</option>)}
              </Form.Select>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="light" onClick={() => setBookingModal(false)}>Cancel</Button>
            <Button type="submit" variant="warning">Update Booking</Button>
          </Modal.Footer>
        </Form>
      </Modal>

    </div>
  );
};

export default AdminDashboard;
