import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Container, Row, Col, Card, Button, Modal, Form, 
  Alert, Spinner, Badge 
} from 'react-bootstrap';
import { 
  FaPlus, FaEdit, FaTrash, FaMapMarkerAlt, FaTint, 
  FaSeedling, FaTractor, FaChartLine, FaWater, FaLeaf,
  FaCity, FaRegBuilding, FaSun, FaCloudSun, 
  FaTemperatureHigh, FaWind, FaTree, FaHeartbeat
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';

const FarmsPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [farms, setFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingFarm, setEditingFarm] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    location: {
      address: '',
      city: '',
      state: '',
      pincode: ''
    },
    size: { value: '', unit: 'acre' },
    soilType: '',
    irrigationType: '',
    waterSource: '',
    ownership: 'owned'
  });

  const getAuthHeaders = () => ({
    headers: { 
      Authorization: `Bearer ${localStorage.getItem('token')}` 
    }
  });

  useEffect(() => {
    fetchFarms();
  }, []);

  const fetchFarms = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:5000/api/farms', getAuthHeaders());
      setFarms(response.data);
    } catch (error) {
      console.error('Error fetching farms:', error);
      if (error.response?.status === 401) {
        toast.error('Please login again');
        navigate('/login');
      } else {
        toast.error('Failed to load farms');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (farm = null) => {
    if (farm) {
      setEditingFarm(farm);
      setFormData({
        name: farm.name,
        location: farm.location || { address: '', city: '', state: '', pincode: '' },
        size: farm.size || { value: '', unit: 'acre' },
        soilType: farm.soilType || '',
        irrigationType: farm.irrigationType || '',
        waterSource: farm.waterSource || '',
        ownership: farm.ownership || 'owned'
      });
    } else {
      setEditingFarm(null);
      setFormData({
        name: '',
        location: { address: '', city: '', state: '', pincode: '' },
        size: { value: '', unit: 'acre' },
        soilType: '',
        irrigationType: '',
        waterSource: '',
        ownership: 'owned'
      });
    }
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: { ...prev[parent], [child]: value }
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleLocationChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      location: { ...prev.location, [name]: value }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      if (editingFarm) {
        await axios.put(`http://localhost:5000/api/farms/${editingFarm._id}`, formData, getAuthHeaders());
        toast.success('Farm updated successfully!');
      } else {
        await axios.post('http://localhost:5000/api/farms', formData, getAuthHeaders());
        toast.success('Farm created successfully!');
      }
      
      setShowModal(false);
      fetchFarms();
    } catch (error) {
      console.error('Error saving farm:', error);
      toast.error(error.response?.data?.message || 'Failed to save farm');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this farm? All associated crops will also be deleted.')) {
      try {
        await axios.delete(`http://localhost:5000/api/farms/${id}`, getAuthHeaders());
        toast.success('Farm deleted successfully');
        fetchFarms();
      } catch (error) {
        console.error('Error deleting farm:', error);
        toast.error('Failed to delete farm');
      }
    }
  };

  const getSoilTypeColor = (soilType) => {
    const colors = {
      clay: '#d32f2f',
      sandy: '#ff9800',
      loamy: '#4caf50',
      silt: '#00bcd4',
      peaty: '#9c27b0',
      chalky: '#9e9e9e'
    };
    return colors[soilType] || '#6c757d';
  };

  const getSoilTypeIcon = (soilType) => {
    switch(soilType) {
      case 'clay': return '🏺';
      case 'sandy': return '🏜️';
      case 'loamy': return '🌱';
      case 'silt': return '💧';
      default: return '🌾';
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #e8f5e9', borderTopColor: '#2e7d32', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#4caf50', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading your farms...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <Container fluid className="mt-4 px-4">
        <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
          <div>
            <div className="d-flex align-items-center gap-2">
              <FaTractor style={{ color: '#1d9223', fontSize: '28px' }} />
              <h2 className="gradient-text mb-1">My Farms</h2>
            </div>
            <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Manage and monitor all your farming operations</p>
          </div>
          <Button variant="success" onClick={() => handleOpenModal()} className="btn-gradient rounded-pill px-4">
            <FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add New Farm
          </Button>
        </div>

        {farms.length === 0 ? (
          <Card className="text-center py-5 shadow-sm">
            <Card.Body>
              <div style={{ width: '80px', height: '80px', margin: '0 auto 20px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e8f5e9', borderRadius: '50%' }}>
                <FaTractor size={40} style={{ color: '#2e7d32' }} />
              </div>
              <h4>No Farms Yet</h4>
              <p className="text-muted">Get started by adding your first farm.</p>
              <Button variant="success" onClick={() => handleOpenModal()}>
                <FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add Your First Farm
              </Button>
            </Card.Body>
          </Card>
        ) : (
          <Row className="g-4">
            {farms.map((farm) => (
              <Col lg={6} xl={4} key={farm._id}>
                <Card className="h-100 card-hover shadow-sm">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-start mb-3">
                      <div>
                        <div className="d-flex align-items-center gap-2 mb-2">
                          <FaLeaf style={{ color: '#2e7d32', fontSize: '20px' }} />
                          <h4 className="mb-1">{farm.name}</h4>
                        </div>
                        <div className="d-flex flex-wrap gap-2">
                          <Badge bg="secondary" className="px-2 py-1">
                            {farm.ownership === 'owned' ? '👑 Owned' : farm.ownership === 'leased' ? '📄 Leased' : '🤝 Shared'}
                          </Badge>
                          {farm.soilType && (
                            <Badge style={{ backgroundColor: getSoilTypeColor(farm.soilType) }} className="px-2 py-1">
                              {getSoilTypeIcon(farm.soilType)} {farm.soilType} soil
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="d-flex gap-1">
                        <Button 
                          variant="link" 
                          size="sm" 
                          className="p-2 border-0"
                          style={{ backgroundColor: 'rgba(46, 125, 50, 0.1)', borderRadius: '8px' }}
                          onClick={() => handleOpenModal(farm)}
                        >
                          <FaEdit style={{ color: '#2e7d32', fontSize: '16px' }} />
                        </Button>
                        <Button 
                          variant="link" 
                          size="sm"
                          className="p-2 border-0"
                          style={{ backgroundColor: 'rgba(244, 67, 54, 0.1)', borderRadius: '8px' }}
                          onClick={() => handleDelete(farm._id)}
                        >
                          <FaTrash style={{ color: '#f44336', fontSize: '16px' }} />
                        </Button>
                      </div>
                    </div>

                    <div className="mb-3">
                      {farm.location?.city && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaCity style={{ color: '#1976d2', fontSize: '14px' }} />
                          </div>
                          <small className="text-muted">
                            {farm.location.city}
                            {farm.location.state ? `, ${farm.location.state}` : ''}
                          </small>
                        </div>
                      )}
                      
                      {farm.size?.value && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaTractor style={{ color: '#2e7d32', fontSize: '14px' }} />
                          </div>
                          <small className="text-muted">{farm.size.value} {farm.size.unit}</small>
                        </div>
                      )}
                      
                      {farm.irrigationType && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaTint style={{ color: '#00bcd4', fontSize: '14px' }} />
                          </div>
                          <small className="text-capitalize text-muted">{farm.irrigationType} irrigation</small>
                        </div>
                      )}

                      {farm.waterSource && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaWater style={{ color: '#2196f3', fontSize: '14px' }} />
                          </div>
                          <small className="text-muted">{farm.waterSource} source</small>
                        </div>
                      )}
                    </div>

                    <div className="mt-3 d-flex gap-2">
                      <Button 
                        variant="outline-primary" 
                        size="sm"
                        onClick={() => navigate(`/crops?farm=${farm._id}`)}
                        style={{ borderColor: '#1976d2', color: '#1976d2' }}
                      >
                        <FaSeedling className="me-1" style={{ color: '#1976d2' }} /> View Crops
                      </Button>
                      <Button 
                        variant="outline-info" 
                        size="sm"
                        onClick={() => navigate(`/analytics?farm=${farm._id}`)}
                        style={{ borderColor: '#00bcd4', color: '#00bcd4' }}
                      >
                        <FaChartLine className="me-1" style={{ color: '#00bcd4' }} /> Analytics
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}

        {/* Add/Edit Farm Modal */}
        <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
          <Modal.Header closeButton style={{ background: 'linear-gradient(135deg, #2e7d32, #4caf50)', color: 'white' }}>
            <Modal.Title>
              {editingFarm ? (
                <><FaEdit className="me-2" style={{ color: '#ffffff' }} /> Edit Farm</>
              ) : (
                <><FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add New Farm</>
              )}
            </Modal.Title>
          </Modal.Header>
          <Form onSubmit={handleSubmit}>
            <Modal.Body>
              <Form.Group className="mb-3">
                <Form.Label className="fw-bold">Farm Name <span className="text-danger">*</span></Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  placeholder="e.g., Green Valley Farm"
                />
              </Form.Group>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Size</Form.Label>
                    <Form.Control
                      type="number"
                      name="size.value"
                      value={formData.size.value}
                      onChange={handleChange}
                      placeholder="Size"
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Unit</Form.Label>
                    <Form.Select name="size.unit" value={formData.size.unit} onChange={handleChange}>
                      <option value="acre">Acre</option>
                      <option value="hectare">Hectare</option>
                      <option value="sq-meter">Square Meter</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Soil Type</Form.Label>
                    <Form.Select name="soilType" value={formData.soilType} onChange={handleChange}>
                      <option value="">Select soil type</option>
                      <option value="clay">Clay</option>
                      <option value="sandy">Sandy</option>
                      <option value="loamy">Loamy</option>
                      <option value="silt">Silt</option>
                      <option value="peaty">Peaty</option>
                      <option value="chalky">Chalky</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Irrigation Type</Form.Label>
                    <Form.Select name="irrigationType" value={formData.irrigationType} onChange={handleChange}>
                      <option value="">Select irrigation type</option>
                      <option value="drip">Drip Irrigation</option>
                      <option value="sprinkler">Sprinkler</option>
                      <option value="flood">Flood</option>
                      <option value="rain-fed">Rain-fed</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Water Source</Form.Label>
                    <Form.Select name="waterSource" value={formData.waterSource} onChange={handleChange}>
                      <option value="">Select water source</option>
                      <option value="borewell">Borewell</option>
                      <option value="river">River</option>
                      <option value="canal">Canal</option>
                      <option value="rain">Rain</option>
                      <option value="pond">Pond</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Ownership</Form.Label>
                    <Form.Select name="ownership" value={formData.ownership} onChange={handleChange}>
                      <option value="owned">Owned</option>
                      <option value="leased">Leased</option>
                      <option value="shared">Shared</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <h6 className="mb-3 mt-3">
                <FaMapMarkerAlt className="me-2" style={{ color: '#f44336' }} /> Location (Optional)
              </h6>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>City</Form.Label>
                    <Form.Control
                      type="text"
                      name="city"
                      value={formData.location.city}
                      onChange={handleLocationChange}
                      placeholder="City"
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>State</Form.Label>
                    <Form.Control
                      type="text"
                      name="state"
                      value={formData.location.state}
                      onChange={handleLocationChange}
                      placeholder="State"
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Form.Group className="mb-3">
                <Form.Label>Pincode</Form.Label>
                <Form.Control
                  type="text"
                  name="pincode"
                  value={formData.location.pincode}
                  onChange={handleLocationChange}
                  placeholder="Postal code"
                />
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowModal(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="success" disabled={submitting}>
                {submitting ? 'Saving...' : (editingFarm ? 'Update Farm' : 'Create Farm')}
              </Button>
            </Modal.Footer>
          </Form>
        </Modal>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .btn-gradient {
          background: linear-gradient(135deg, #2e7d32, #4caf50);
          border: none;
          transition: transform 0.3s ease;
        }
        .btn-gradient:hover {
          transform: translateY(-2px);
        }
        .card-hover {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </>
  );
};

export default FarmsPage;