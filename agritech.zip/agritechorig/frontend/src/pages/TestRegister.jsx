import React, { useState } from 'react';
import axios from 'axios';

const TestRegister = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    role: 'farmer'
  });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/auth/register', formData);
      setMessage(`✅ Registration successful! Welcome ${response.data.name}`);
      console.log('User registered:', response.data);
    } catch (error) {
      setMessage(`❌ Error: ${error.response?.data?.message || error.message}`);
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '50px auto', padding: '20px' }}>
      <h2>🌾 Farmer Registration</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Full Name" onChange={handleChange} required />
        <br />
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
        <br />
        <input type="password" name="password" placeholder="Password (min 6 chars)" onChange={handleChange} required />
        <br />
        <input type="tel" name="phone" placeholder="Phone Number" onChange={handleChange} />
        <br />
        <select name="role" onChange={handleChange}>
          <option value="farmer">Farmer</option>
          <option value="expert">Agricultural Expert</option>
        </select>
        <br />
        <button type="submit">Register</button>
      </form>
      <p>{message}</p>
    </div>
  );
};

export default TestRegister;