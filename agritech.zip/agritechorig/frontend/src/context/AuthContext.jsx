import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';
import { login as apiLogin, register as apiRegister, getProfile } from '../services/authService';
import { toast } from 'react-toastify';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('token'));

  // Set up axios default headers when token changes
  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      delete axios.defaults.headers.common['Authorization'];
    }
  }, [token]);

  useEffect(() => {
    if (token) {
      loadUser();
    } else {
      setLoading(false);
    }
  }, [token]);

  const loadUser = async () => {
    try {
      const userData = await getProfile();
      setUser(userData);
      // Update localStorage with latest user data
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        const oldUser = JSON.parse(storedUser);
        localStorage.setItem('user', JSON.stringify({ ...oldUser, ...userData }));
      } else {
        localStorage.setItem('user', JSON.stringify(userData));
      }
    } catch (error) {
      console.error('Failed to load user:', error);
      localStorage.removeItem('token');
      setToken(null);
      delete axios.defaults.headers.common['Authorization'];
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    try {
      const response = await apiLogin(email, password);
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response));
      setToken(response.token);
      setUser(response);
      axios.defaults.headers.common['Authorization'] = `Bearer ${response.token}`;
      toast.success(`Welcome back, ${response.name}!`);
      return response;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Login failed');
      throw error;
    }
  };

  const register = async (userData) => {
    try {
      const response = await apiRegister(userData);
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response));
      setToken(response.token);
      setUser(response);
      axios.defaults.headers.common['Authorization'] = `Bearer ${response.token}`;
      toast.success('Registration successful! Welcome to Agri-Tech!');
      return response;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Registration failed');
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
    delete axios.defaults.headers.common['Authorization'];
    toast.info('Logged out successfully');
  };

  // Function to refresh user data (call after profile update)
  const refreshUser = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;
      
      const response = await axios.get('http://localhost:5000/api/auth/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const userData = response.data;
      setUser(userData);
      
      // Update localStorage with latest user data
      const storedUser = localStorage.getItem('user');
      if (storedUser) {
        const oldUser = JSON.parse(storedUser);
        localStorage.setItem('user', JSON.stringify({ ...oldUser, ...userData }));
      } else {
        localStorage.setItem('user', JSON.stringify(userData));
      }
      
      // Also update axios default header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      
      console.log('User data refreshed:', userData);
      return userData;
    } catch (error) {
      console.error('Failed to refresh user:', error);
      if (error.response?.status === 401) {
        // Token expired, logout user
        logout();
      }
      throw error;
    }
  };

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    refreshUser,
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
    isFarmer: user?.role === 'farmer',
    isExpert: user?.role === 'expert',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};