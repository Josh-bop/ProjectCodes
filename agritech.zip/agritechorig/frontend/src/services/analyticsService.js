import api from './api';

export const getYieldData = async () => {
  const response = await api.get('/analytics/yield');
  return response.data;
};

export const getWeatherData = async (lat, lon) => {
  const response = await api.get(`/analytics/weather`, { params: { lat, lon } });
  return response.data;
};

export const getMarketPrices = async () => {
  const response = await api.get('/analytics/market-prices');
  return response.data;
};