import api from './api';

export const addCrop = async (cropData) => {
  const response = await api.post('/crops', cropData);
  return response.data;
};

export const getUserCrops = async () => {
  const response = await api.get('/crops');
  return response.data;
};

export const getCropsByFarm = async (farmId) => {
  const response = await api.get(`/crops/farm/${farmId}`);
  return response.data;
};

export const getCropById = async (id) => {
  const response = await api.get(`/crops/${id}`);
  return response.data;
};

export const updateCrop = async (id, cropData) => {
  const response = await api.put(`/crops/${id}`, cropData);
  return response.data;
};

export const updateGrowthStage = async (id, growthStage, health) => {
  const response = await api.put(`/crops/${id}/growth-stage`, { growthStage, health });
  return response.data;
};

export const reportIssue = async (id, issueData) => {
  const response = await api.post(`/crops/${id}/report-issue`, issueData);
  return response.data;
};

export const deleteCrop = async (id) => {
  const response = await api.delete(`/crops/${id}`);
  return response.data;
};