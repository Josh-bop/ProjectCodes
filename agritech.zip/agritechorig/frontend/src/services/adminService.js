import api from './api';

export const getSystemStats    = async ()       => (await api.get('/admin/stats')).data;
export const getAllUsers        = async (params) => (await api.get('/admin/users', { params })).data;
export const getUserById        = async (id)     => (await api.get(`/admin/users/${id}`)).data;
export const updateUser         = async (id, d)  => (await api.put(`/admin/users/${id}`, d)).data;
export const deleteUser         = async (id)     => (await api.delete(`/admin/users/${id}`)).data;

export const getAllBookings      = async ()       => (await api.get('/admin/bookings')).data;
export const updateBookingStatus = async (id, d) => (await api.put(`/admin/bookings/${id}`, d)).data;

export const getAllProductsAdmin = async ()       => (await api.get('/admin/products')).data;

export const getAllForumPosts    = async ()       => (await api.get('/admin/forum')).data;
export const deleteForumPost    = async (id)     => (await api.delete(`/admin/forum/${id}`)).data;

export const getAllFarmsAdmin    = async ()       => (await api.get('/admin/farms')).data;
export const getAllCropsAdmin    = async ()       => (await api.get('/admin/crops')).data;
