const Farm = require('../models/Farm');
const Crop = require('../models/Crop');

// @desc    Create a farm
// @route   POST /api/farms
// @access  Private
const createFarm = async (req, res) => {
  try {
    const farm = await Farm.create({
      ...req.body,
      user: req.user._id,
    });
    res.status(201).json(farm);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all farms for a user
// @route   GET /api/farms
// @access  Private
const getUserFarms = async (req, res) => {
  try {
    const farms = await Farm.find({ user: req.user._id }).sort('-createdAt');
    res.json(farms);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single farm
// @route   GET /api/farms/:id
// @access  Private
const getFarmById = async (req, res) => {
  try {
    const farm = await Farm.findOne({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    // Get crops for this farm
    const crops = await Crop.find({ farm: farm._id });
    
    res.json({ ...farm.toObject(), crops });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update farm
// @route   PUT /api/farms/:id
// @access  Private
const updateFarm = async (req, res) => {
  try {
    const farm = await Farm.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    res.json(farm);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete farm
// @route   DELETE /api/farms/:id
// @access  Private
const deleteFarm = async (req, res) => {
  try {
    const farm = await Farm.findOneAndDelete({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    // Delete all crops associated with this farm
    await Crop.deleteMany({ farm: farm._id });
    
    res.json({ message: 'Farm deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get farm statistics
// @route   GET /api/farms/:id/stats
// @access  Private
const getFarmStats = async (req, res) => {
  try {
    const farm = await Farm.findOne({
      _id: req.params.id,
      user: req.user._id,
    });
    
    if (!farm) {
      return res.status(404).json({ message: 'Farm not found' });
    }
    
    const crops = await Crop.find({ farm: farm._id });
    
    const stats = {
      totalCrops: crops.length,
      activeCrops: crops.filter(c => c.growthStage !== 'harvesting' && c.growthStage !== 'fallow').length,
      totalArea: crops.reduce((sum, crop) => sum + (crop.areaPlanted?.value || 0), 0),
      averageHealth: crops.reduce((sum, crop) => {
        const healthScore = { excellent: 5, good: 4, fair: 3, poor: 2, critical: 1 };
        return sum + (healthScore[crop.health] || 3);
      }, 0) / (crops.length || 1),
    };
    
    res.json(stats);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createFarm,
  getUserFarms,
  getFarmById,
  updateFarm,
  deleteFarm,
  getFarmStats,
};