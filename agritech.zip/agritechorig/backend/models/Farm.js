const mongoose = require('mongoose');

const farmSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: [true, 'Please add a farm name'],
    trim: true,
  },
  location: {
    address: String,
    city: String,
    state: String,
    pincode: String,
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  size: {
    value: {
      type: Number,
      required: true,
    },
    unit: {
      type: String,
      enum: ['acre', 'hectare', 'sq-meter'],
      default: 'acre',
    },
  },
  soilType: {
    type: String,
    enum: ['clay', 'sandy', 'loamy', 'silt', 'peaty', 'chalky'],
  },
  soilHealth: {
    ph: {
      type: Number,
      min: 0,
      max: 14,
    },
    nitrogen: Number,
    phosphorus: Number,
    potassium: Number,
    organicMatter: Number,
    lastTested: Date,
  },
  irrigationType: {
    type: String,
    enum: ['drip', 'sprinkler', 'flood', 'rain-fed', 'center-pivot'],
  },
  waterSource: {
    type: String,
    enum: ['borewell', 'river', 'canal', 'rain', 'pond'],
  },
  ownership: {
    type: String,
    enum: ['owned', 'leased', 'shared'],
    default: 'owned',
  },
  images: [String],
  isActive: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Farm', farmSchema);