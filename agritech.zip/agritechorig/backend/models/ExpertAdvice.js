const mongoose = require('mongoose');

const expertAdviceSchema = new mongoose.Schema({
  expert: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  content: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    enum: ['crop_management', 'pest_control', 'irrigation', 'soil_health', 'fertilization', 'harvesting'],
    required: true,
  },
  tags: [String],
  applicableCrops: [String],
  applicableRegions: [String],
  difficulty: {
    type: String,
    enum: ['beginner', 'intermediate', 'advanced'],
    default: 'intermediate',
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  isPublished: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('ExpertAdvice', expertAdviceSchema);