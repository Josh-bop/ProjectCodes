const express = require('express');
const {
  createPost,
  getAllPosts,
  getPostById,
  updatePost,
  deletePost,
  addComment,
  likePost,
  acceptAnswer,
} = require('../controllers/forumController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/posts')
  .post(protect, createPost)
  .get(getAllPosts);

router.get('/posts/:id', getPostById);
router.put('/posts/:id', protect, updatePost);
router.delete('/posts/:id', protect, deletePost);
router.post('/posts/:id/comments', protect, addComment);
router.post('/posts/:id/like', protect, likePost);
router.put('/comments/:commentId/accept', protect, acceptAnswer);

module.exports = router;